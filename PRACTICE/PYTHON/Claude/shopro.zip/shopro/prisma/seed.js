const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

const categories = [
  { name: 'Electronice', emoji: '💻' },
  { name: 'Îmbrăcăminte', emoji: '👕' },
  { name: 'Casă & Grădină', emoji: '🪴' },
  { name: 'Sport', emoji: '⚽' },
  { name: 'Frumusețe', emoji: '💄' },
  { name: 'Jucării', emoji: '🧸' },
  { name: 'Cărți', emoji: '📚' },
  { name: 'Alimentare', emoji: '🍎' },
];

const productData = {
  'Electronice': [
    { name: 'Telefon Smart Pro', emoji: '📱', price: 1299, oldPrice: 1599, stock: 25, isNew: true, description: 'Telefon flagship cu cameră de 108MP, baterie 5000mAh și display AMOLED 6.7"' },
    { name: 'Laptop Ultra Slim', emoji: '💻', price: 3499, stock: 12, isNew: true, description: 'Laptop subțire cu procesor i7, 16GB RAM, SSD 512GB și autonomie 12 ore' },
    { name: 'Căști Wireless Elite', emoji: '🎧', price: 449, oldPrice: 599, stock: 38, description: 'Căști over-ear cu noise cancelling activ, 30h autonomie și sunet Hi-Res' },
    { name: 'Tabletă Premium', emoji: '📱', price: 1899, stock: 18, description: 'Tabletă 10" cu display Retina, 128GB stocare, ideală pentru productivitate' },
    { name: 'Ceas Smart Fitness', emoji: '⌚', price: 699, oldPrice: 899, stock: 42, description: 'Smartwatch cu monitorizare sănătate, GPS integrat și rezistență la apă 50m' },
    { name: 'Boxă Portabilă', emoji: '🔊', price: 299, stock: 55, description: 'Boxă Bluetooth 360° cu sunet surround, rezistentă la apă IPX7, 20h muzică' },
    { name: 'Monitor Gaming 4K', emoji: '🖥️', price: 2199, stock: 8, isNew: true, description: 'Monitor 27" 4K IPS, 144Hz, 1ms, HDR400, perfect pentru gaming și design' },
    { name: 'Cameră Mirrorless', emoji: '📷', price: 4299, oldPrice: 4999, stock: 6, description: 'Cameră foto 24MP cu stabilizare optică, video 4K30fps, kit cu obiectiv 18-55mm' },
    { name: 'Baterie Externă 20000mAh', emoji: '🔋', price: 189, stock: 70, description: 'Power bank cu încărcare rapidă 65W, compatibil USB-C și Lightning' },
    { name: 'Router WiFi 6', emoji: '📡', price: 399, stock: 30, description: 'Router WiFi 6 AX3000, acoperire 200mp, ideal pentru smart home și streaming 4K' },
    { name: 'Consolă Gaming Portabilă', emoji: '🎮', price: 1599, isNew: true, stock: 15, description: 'Consolă portabilă cu display 7" OLED, autonomie 8h, bibliotecă de 5000 jocuri' },
    { name: 'Bec Smart RGB', emoji: '💡', price: 89, stock: 150, description: 'Bec LED smart 16 milioane culori, control vocal Alexa/Google, consum 9W' },
  ],
  'Îmbrăcăminte': [
    { name: 'Tricou Bumbac Premium', emoji: '👕', price: 89, stock: 120, description: 'Tricou 100% bumbac organic, disponibil în 8 culori, croială relaxed fit' },
    { name: 'Geacă Impermeabilă', emoji: '🧥', price: 599, oldPrice: 799, stock: 35, description: 'Geacă outdoor impermeabilă 3 straturi, izolație termică, buzunare multiple' },
    { name: 'Adidași Running', emoji: '👟', price: 449, stock: 60, isNew: true, description: 'Pantofi alergare cu amortizare gel, respirabili, talpă anti-alunecare' },
    { name: 'Pantaloni Slim Fit', emoji: '👖', price: 199, oldPrice: 249, stock: 80, description: 'Pantaloni eleganți slim fit, material stretch, disponibili în 5 culori' },
    { name: 'Rochie de Vară', emoji: '👗', price: 249, stock: 45, isNew: true, description: 'Rochie florală din viscoză, lungime midi, bretele reglabile, perfectă pentru vară' },
    { name: 'Pulover Caș Merinos', emoji: '🧶', price: 329, oldPrice: 449, stock: 28, description: 'Pulover din lână merinos extra-fine, hipoalergenic, păstrează căldura optim' },
    { name: 'Șapcă Baseball', emoji: '🧢', price: 79, stock: 200, description: 'Șapcă reglabilă din bumbac, broderie față, disponibilă în 10 culori și modele' },
    { name: 'Geantă Piele Naturală', emoji: '👜', price: 699, stock: 20, description: 'Geantă din piele naturală full-grain, compartimente multiple, feronerie aurie' },
    { name: 'Fular Caș', emoji: '🧣', price: 129, stock: 90, description: 'Fular larg din caș moale, 180×60cm, colorit elegant, se purtă în mai multe stiluri' },
    { name: 'Lenjerie Termică', emoji: '🩱', price: 159, oldPrice: 199, stock: 55, description: 'Set lenjerie termoactivă pentru sport de iarnă, material tehnic respirabil' },
    { name: 'Costum Baie', emoji: '🩳', price: 149, stock: 65, description: 'Costum de baie rezistent la clor, uscare rapidă, protecție UV 50+' },
    { name: 'Mănuși Piele', emoji: '🧤', price: 179, oldPrice: 229, stock: 40, description: 'Mănuși din piele nappa, căptușeală cașmir, compatibile touchscreen' },
  ],
  'Casă & Grădină': [
    { name: 'Set Vase Ceramică', emoji: '🍳', price: 349, stock: 25, description: 'Set 5 piese ceramică premium fără PTFE, inducție compatibil, design scandinav' },
    { name: 'Plantă Monstera XXL', emoji: '🪴', price: 189, stock: 15, isNew: true, description: 'Monstera Deliciosa cu frunze mari, ghiveci ceramic inclus, înălțime 80-100cm' },
    { name: 'Lumânare Parfumată', emoji: '🕯️', price: 79, stock: 200, description: 'Lumânare din ceară de soia, parfum vanilie & cedru, durată ardere 50h' },
    { name: 'Pernuțe Decorative Set 4', emoji: '🛋️', price: '219', stock: 30, description: 'Set 4 perne decorative 45×45cm, husă velur detașabilă, umplutură premium' },
    { name: 'Oglindă Rotundă Gold', emoji: '🪞', price: 459, oldPrice: 599, stock: 12, description: 'Oglindă rotundă Ø60cm cu ramă metalică aurie, perfectă pentru hol sau dormitor' },
    { name: 'Coș Răchită Natural', emoji: '🧺', price: 129, stock: 40, description: 'Coș depozitare din răchită naturală, handmade, dimensiuni 35×25×25cm' },
    { name: 'Set Cuțite Profesional', emoji: '🔪', price: 699, oldPrice: 899, stock: 8, description: 'Set 7 cuțite oțel german X50CrMoV15, bloc lemn inclus, echilibru perfect' },
    { name: 'Aparat Cafea Espresso', emoji: '☕', price: 1299, stock: 18, isNew: true, description: 'Espressor automat 15 bari, rezervor 1.8L, cappuccino maker integrat, display LCD' },
    { name: 'Covor Persan Modern', emoji: '🏮', price: 899, oldPrice: 1199, stock: 5, description: 'Covor 200×300cm, lână 100%, model geometric colorat, lavabil la 30°' },
    { name: 'Lampă de Podea Arc', emoji: '💡', price: 549, stock: 22, description: 'Lampă arc din metal negru mat, abajur alb, becuri LED incluse, dimmer' },
    { name: 'Răsaduri Mix Ierburi', emoji: '🌱', price: 49, stock: 100, description: 'Set 6 răsaduri ierburi aromatice: busuioc, mentă, rozmarin, cimbru, oregano, tarhon' },
    { name: 'Suport Plante Macramé', emoji: '🧵', price: 89, stock: 60, description: 'Suport agățat macramé handmade, sfori 100% bumbac, include ghiveci ceramic 15cm' },
  ],
  'Sport': [
    { name: 'Saltea Yoga Premium', emoji: '🧘', price: 249, stock: 45, description: 'Saltea yoga 6mm TPE eco-friendly, antiderapantă față/spate, geantă transport inclusă' },
    { name: 'Bicicletă Mountain Pro', emoji: '🚴', price: 2799, oldPrice: 3299, stock: 7, description: 'MTB 29" cadru aluminiu, Shimano 21 viteze, frâne hidraulice, furca telescopică' },
    { name: 'Set Gantere Ajustabile', emoji: '🏋️', price: 599, stock: 20, isNew: true, description: 'Set gantere 2×24kg cu selector rapid, suport inclus, înlocuiesc 15 perechi gantere' },
    { name: 'Sac Box Profesional', emoji: '🥊', price: 449, stock: 18, description: 'Sac box 70cm/30kg piele ecologică, umplutură nisip+textile, lanț reglabil inclus' },
    { name: 'Coardă Săritul Pro', emoji: '🏃', price: 89, oldPrice: 119, stock: 80, description: 'Coardă cu rulmenți din oțel, mânere ergonomice, cablu reglabil, digitală' },
    { name: 'Genți Sport Impermeabile', emoji: '🎒', price: 199, stock: 35, description: 'Rucsac sport 35L impermeabil, compartiment pantofi separat, buzunar laptop' },
    { name: 'Ochelari Înot Racing', emoji: '🏊', price: 129, oldPrice: 169, stock: 50, description: 'Ochelari competiție cu protecție UV, etanșeitate perfectă, lentile antifog' },
    { name: 'Bandă Alergat Smart', emoji: '🏃', price: 3999, stock: 5, isNew: true, description: 'Bandă alergat 3HP, display touchscreen, programe automate, pliabilă, app conectată' },
    { name: 'Mingea Fotbal Profesional', emoji: '⚽', price: 189, stock: 60, description: 'Minge FIFA Quality Pro, piele sintetică premium, rezistentă la apă' },
    { name: 'Rachete Tenis Set', emoji: '🎾', price: 349, stock: 25, description: 'Set 2 rachete carbon 275g, 3 mingi incluse, huse individuale, ideal începători avansați' },
    { name: 'Role Inline Adult', emoji: '🛼', price: 459, oldPrice: 579, stock: 14, description: 'Role inline 80mm, cadru aluminiu, frână spate, echipament protecție inclus' },
    { name: 'Cort Camping 3 Persoane', emoji: '⛺', price: 699, stock: 12, description: 'Cort igloo 3 persoane, impermeabil 3000mm, montare 2 minute, greutate 2.8kg' },
  ],
  'Frumusețe': [
    { name: 'Ser Vitamina C Premium', emoji: '✨', price: 189, stock: 60, isNew: true, description: 'Ser facial 20% vitamina C stabilizată, niacinamidă, acid hialuronic, 30ml' },
    { name: 'Cremă Antirid Luxe', emoji: '🌸', price: '349', oldPrice: 449, stock: 35, description: 'Cremă zi/noapte cu retinol 0.5%, peptide și ceramide, rezultate vizibile în 4 săptămâni' },
    { name: 'Set Machiaj Profesional', emoji: '💄', price: 499, stock: 20, description: '42 piese: 20 farduri, fond de ten, blush, bronzer, iluminator, pensule profesionale' },
    { name: 'Parfum Floral Intense', emoji: '🌺', price: 429, oldPrice: 529, stock: 28, description: 'Eau de Parfum 100ml, note floral-lemnoase, durată 12h, produs în Franța' },
    { name: 'Aparat Styling Păr', emoji: '💇', price: 359, stock: 32, description: 'Multistyler 5 în 1: ondulator, drept, volumizator, placa 230°C, ionizare' },
    { name: 'Masaj Facial Gua Sha', emoji: '💆', price: '149', stock: 75, description: 'Set gua sha cuarț roz natural + rolă jad, manual îngrijire inclus, husă cadou' },
    { name: 'Scrub Corp Zahăr Bio', emoji: '🍯', price: 89, stock: 90, description: 'Scrub exfoliant cu zahăr brun, ulei cocos și lavandă, 300g, vegan certified' },
    { name: 'Patch-uri Ochi Aur', emoji: '👁️', price: 79, stock: 120, description: '60 patch-uri ochi cu aur coloidal, retinol și colagen, atenuează cearcănele' },
    { name: 'Ulei Argan Pur Maroc', emoji: '🫙', price: 129, stock: 55, description: 'Ulei argan 100% pur cold-pressed, certificat organic, multi-use față/corp/păr, 50ml' },
    { name: 'Periuță Sonic Electric', emoji: '🪥', price: 299, oldPrice: 399, stock: 40, description: 'Periuță sonică 40.000 mișcări/min, 5 moduri, timer 2min, autonomie 4 săptămâni' },
    { name: 'Fond de Ten SPF 30', emoji: '🌟', price: 159, stock: 70, isNew: true, description: 'Fond de ten full coverage cu SPF 30, rezistent 24h, 40 nuanțe, formula clean beauty' },
    { name: 'Trusă Cadou Luxury', emoji: '🎁', price: 549, stock: 15, description: 'Trusă cadou premium: cremă corp, ulei parfumat, lapte baie, săpun artizanal, cutie elegantă' },
  ],
  'Jucării': [
    { name: 'LEGO City Set Mare', emoji: '🏗️', price: 299, stock: 30, description: 'Set LEGO 850 piese, construiește un oraș complet, vârsta 8+, certificat siguranță' },
    { name: 'Ursuleț Pluș Gigant', emoji: '🧸', price: 149, oldPrice: 199, stock: 40, description: 'Ursuleț pluș 80cm, material hipoalergenic, lavabil 30°, perfect pentru copii 0+' },
    { name: 'Drone cu Cameră', emoji: '🚁', price: 699, stock: 12, isNew: true, description: 'Drone 4K cu stabilizator gimbal, autonomie 25min, raza 500m, returnare automată' },
    { name: 'Puzzle 3D Arhitectură', emoji: '🏛️', price: 129, stock: 45, description: 'Puzzle 3D 500 piese - Turnul Eiffel, fără lipici, rezistenă structurală, 8+' },
    { name: 'Scuter Electric Copii', emoji: '🛵', price: 849, oldPrice: 999, stock: 8, description: 'Scuter electric până la 15km/h, autonomie 12km, lumini LED, frână sigură, 5-12 ani' },
    { name: 'Set Știință Experimente', emoji: '🔬', price: 179, stock: 35, description: '50 experimente STEM: vulcan, cristale, reacții chimice sigure, manual ilustrat inclus' },
    { name: 'Trambulină 3m', emoji: '🎪', price: 999, stock: 6, description: 'Trambulină outdoor Ø305cm cu plasă siguranță, cadru galvanizat, capacitate 100kg' },
    { name: 'Robot Programabil', emoji: '🤖', price: '449', stock: 18, isNew: true, description: 'Robot educativ programabil vizual, 200+ comenzi, senzori IR/ultrasunete, 8-14 ani' },
    { name: 'Joc de Masă Monopoly Deluxe', emoji: '🎲', price: 199, oldPrice: 249, stock: 50, description: 'Monopoly ediție deluxe cu piese metalice premium, carduri illustrate, 2-8 jucători' },
    { name: 'Piscină Gonflabilă', emoji: '🏊', price: 349, stock: 20, description: 'Piscină gonflabilă familială 300×175×80cm, pompă electrică inclusă, până la 6 ani' },
    { name: 'Figurine Colecție 10 buc', emoji: '🏆', price: 119, stock: 60, description: 'Set 10 figurine colecționabile 8-12cm, personaje diverse, seria limitată 2026' },
    { name: 'Kit Pictură pe Numere', emoji: '🎨', price: 89, stock: 80, description: 'Kit complet: pânză 40×50cm, 24 culori acrilice, pensule, cadru lemn, model peisaj' },
  ],
  'Cărți': [
    { name: 'Sapiens - Yuval Noah Harari', emoji: '📖', price: 59, stock: 100, description: 'Bestseller mondial - O scurtă istorie a omenirii. Traducere în română, ediție nouă' },
    { name: 'Atomic Habits - James Clear', emoji: '📗', price: 49, oldPrice: 59, stock: 80, description: 'Ghid practic pentru obiceiuri bune și renunțarea la obiceiurile proaste. Top 10 vânzări' },
    { name: 'Atlas de Anatomie Netter', emoji: '📘', price: 299, stock: 20, description: 'Atlasul de referință mondial pentru medicii și studenții la medicină, 6ª ediție' },
    { name: 'Agenda Planner 2026', emoji: '📓', price: 79, stock: 150, isNew: true, description: 'Agendă premium A5 cu layout săptămânal, hartă anuală, stickere incluse, copertă piele' },
    { name: 'Enciclopedie Copii 500 pagini', emoji: '📚', price: 129, stock: 35, description: 'Enciclopedie ilustrată 500 pagini pentru copii 6-12 ani, teme: știință, natură, istorie' },
    { name: 'Roman Polițist Bestseller', emoji: '🔍', price: 45, stock: 120, description: 'Cel mai bine vândut roman polițist al anului 2025, traducere din engleză, 400 pagini' },
    { name: 'Caiet Bullet Journal', emoji: '📔', price: '89', stock: 90, description: 'Caiet dot grid A5 180g/mp, copertă tare, bandă elastică, buzunar interior, 200 pagini' },
    { name: 'Set 3 Cărți Motivaționale', emoji: '💪', price: 99, oldPrice: 147, stock: 45, description: 'Set 3 bestsellers: The Power of Now, Think & Grow Rich, 7 Habits - traducere română' },
    { name: 'Carte de Bucate Mediteraneene', emoji: '🍝', price: 89, stock: 60, description: '200 rețete autentice din bazinul mediteranean, fotografii profesionale, 320 pagini' },
    { name: 'Ghid Investiții Bursa', emoji: '📈', price: 69, stock: 75, description: 'Manual practic pentru investiții la bursă pentru începători, ediție actualizată 2025' },
    { name: 'Atlas Geografic Mondial', emoji: '🌍', price: 159, stock: 25, description: 'Atlas complet 256 pagini, hărți actualizate 2025, statistici demografice și economice' },
    { name: 'Colecție Poetry Clasici Români', emoji: '📜', price: '39', stock: 200, description: 'Antologie lirică: Eminescu, Bacovia, Arghezi, Blaga - ediție de colecție cu ilustrații' },
  ],
  'Alimentare': [
    { name: 'Cafea Specialty Etiopia', emoji: '☕', price: 89, stock: 80, description: 'Cafea single origin Yirgacheffe 250g, prăjire medie, note de citrice și iasomie, specialitate' },
    { name: 'Miere Poliflora Bio 1kg', emoji: '🍯', price: 79, oldPrice: 99, stock: 100, description: 'Miere crudă poliflora certificată bio, apicultori locali, nepasteurizată, borcan 1kg' },
    { name: 'Ciocolată Artizanală 70%', emoji: '🍫', price: 29, stock: 200, description: 'Tableta ciocolată neagră 70% cacao Ecuador, bean-to-bar, fără zahăr rafinat, 100g' },
    { name: 'Ulei Măsline Extra Virgin', emoji: '🫒', price: 69, stock: 90, description: 'Ulei măsline EV grecesc 500ml, aciditate <0.3%, presat la rece, DOP certificat' },
    { name: 'Mix Nuci și Fructe Exotice', emoji: '🥜', price: 49, stock: 150, description: 'Amestec premium 500g: caju, migdale, macadamia, ananas, mango, stafide sultanine' },
    { name: 'Paste Artizanale Italiene', emoji: '🍝', price: 35, stock: 120, description: 'Paste bronzate organic din grâu dur Semola, 500g, sortiment: pappardelle' },
    { name: 'Vin Roșu Premium Dealu Mare', emoji: '🍷', price: 89, oldPrice: 109, stock: 60, description: 'Cabernet Sauvignon 2021 Dealu Mare, 750ml, medaliat la concursuri internaționale' },
    { name: 'Ceai Bio Colecție 20 arome', emoji: '🍵', price: 59, stock: 80, description: 'Cutie cadou 20 arome ceai organic: verde, negru, herbal, oolong, rooibos, fructe' },
    { name: 'Somon Afumat Norwegian', emoji: '🐟', price: 129, stock: 30, description: 'Somon atlantic afumat la rece 200g, origine Norvegia, feliat, ambalat vid, congelare' },
    { name: 'Brânză Maturată Artizanală', emoji: '🧀', price: 79, stock: 40, description: 'Brânză maturată 12 luni de la producător local, roată 300g, crustă naturală' },
    { name: 'Oțet Balsamic Modena IGP', emoji: '🍶', price: 89, stock: 50, description: 'Oțet balsamic tradițional Modena 250ml, maturare 12 ani, gust dulce-acrișor, IGP' },
    { name: 'Granola Artizanală 500g', emoji: '🌾', price: 45, stock: 110, description: 'Granola crocantă cu ovăz, migdale, miere, scorțișoară, coacăze, fără conservanți' },
  ],
};

async function main() {
  console.log('🌱 Seeding database...');

  // Clear existing data
  await prisma.review.deleteMany();
  await prisma.cartItem.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.product.deleteMany();
  await prisma.category.deleteMany();
  await prisma.user.deleteMany();

  // Create admin user
  const adminPass = await bcrypt.hash('admin123', 10);
  const admin = await prisma.user.create({
    data: { name: 'Administrator', email: 'admin@shopro.ro', password: adminPass, role: 'admin' }
  });

  // Create test client
  const clientPass = await bcrypt.hash('client123', 10);
  const client = await prisma.user.create({
    data: { name: 'Ion Popescu', email: 'client@shopro.ro', password: clientPass, role: 'client' }
  });

  console.log('✅ Users created');

  // Create categories and products
  let totalProducts = 0;
  for (const cat of categories) {
    const category = await prisma.category.create({ data: cat });
    const prods = productData[cat.name] || [];
    for (const p of prods) {
      await prisma.product.create({
        data: {
          name: p.name,
          description: p.description || '',
          emoji: p.emoji,
          price: typeof p.price === 'string' ? parseFloat(p.price) : p.price,
          oldPrice: p.oldPrice || null,
          stock: p.stock,
          isNew: p.isNew || false,
          categoryId: category.id,
        }
      });
      totalProducts++;
    }
    console.log(`  ✅ ${cat.name}: ${prods.length} produse`);
  }

  // Create sample orders
  const allProducts = await prisma.product.findMany({ take: 5 });
  const order1 = await prisma.order.create({
    data: {
      userId: client.id,
      total: 847,
      status: 'Expediata',
      name: 'Ion Popescu',
      address: 'Str. Florilor 12, Ap. 4',
      city: 'București',
      phone: '0722 123 456',
      items: {
        create: [
          { productId: allProducts[0].id, qty: 1, price: allProducts[0].price },
          { productId: allProducts[1].id, qty: 2, price: allProducts[1].price },
        ]
      }
    }
  });

  await prisma.order.create({
    data: {
      userId: client.id,
      total: 299,
      status: 'Plasata',
      name: 'Ion Popescu',
      address: 'Str. Florilor 12, Ap. 4',
      city: 'Cluj-Napoca',
      phone: '0722 123 456',
      items: { create: [{ productId: allProducts[2].id, qty: 1, price: allProducts[2].price }] }
    }
  });

  // Add sample reviews
  await prisma.review.create({
    data: {
      userId: client.id,
      productId: allProducts[0].id,
      rating: 5,
      comment: 'Produs excelent! Calitate superioară, livrare rapidă. Recomand cu încredere!'
    }
  });

  console.log(`\n✅ Database seeded!`);
  console.log(`   👥 2 utilizatori (admin@shopro.ro / admin123 și client@shopro.ro / client123)`);
  console.log(`   📦 ${totalProducts} produse în ${categories.length} categorii`);
  console.log(`   🛍️ 2 comenzi de test`);
  console.log(`   ⭐ 1 recenzie de test`);
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
