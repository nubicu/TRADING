# ShopRO — Magazin Online Local

Aplicație completă de e-commerce cu bază de date reală (SQLite).

## Ce include

- **96 produse** în 8 categorii, generate automat
- **Autentificare** (login/register) cu NextAuth
- **Coș de cumpărături** persistent (salvat în baza de date)
- **Checkout** cu formular de livrare
- **Comenzi** cu status și istoric
- **Panou Admin** complet (produse, comenzi, statistici)
- **Bază de date SQLite** — un singur fișier local, zero configurare server

---

## Instalare și pornire (Windows)

### Pasul 1 — Deschide folderul în terminal

```
# Click dreapta pe folderul shopro → "Open in Terminal"
# sau Win+R → cmd → cd C:\cale\catre\shopro
```

### Pasul 2 — Instalează dependențele

```bash
npm install
```

Durează 2-3 minute la prima instalare.

### Pasul 3 — Creează baza de date și adaugă produsele

```bash
npm run setup
```

Acest comandă face automat:
1. Creează fișierul `prisma/shopro.db` (baza de date SQLite)
2. Creează tabelele (users, products, categories, orders, etc.)
3. Adaugă 96 produse + 2 conturi de test

### Pasul 4 — Pornește aplicația

```bash
npm run dev
```

Deschide în browser: **http://localhost:3000**

---

## Conturi de test

| Email | Parolă | Rol |
|-------|--------|-----|
| admin@shopro.ro | admin123 | Admin (acces panou admin) |
| client@shopro.ro | client123 | Client normal |

---

## Pagini disponibile

| Pagină | URL |
|--------|-----|
| Magazin (produse + filtre) | http://localhost:3000 |
| Autentificare | http://localhost:3000/auth |
| Coș de cumpărături | http://localhost:3000/cart |
| Comenzile mele | http://localhost:3000/orders |
| Panou Admin | http://localhost:3000/admin |

---

## Cum funcționează baza de date

- Fișierul bazei de date este: `prisma/shopro.db`
- Este un fișier SQLite — poți inspecta cu **DB Browser for SQLite** (gratuit)
- Datele se păstrează între sesiuni
- Pentru a reseta totul: `npm run db:seed`
- Pentru a vedea datele vizual: `npm run db:studio` (deschide Prisma Studio în browser)

---

## Structura proiectului

```
shopro/
├── app/
│   ├── page.tsx          # Pagina principală (magazin)
│   ├── auth/             # Login & Register
│   ├── cart/             # Coș de cumpărături
│   ├── orders/           # Istoricul comenzilor
│   ├── admin/            # Panou administrare
│   └── api/              # API Routes (backend)
│       ├── auth/         # NextAuth + register
│       ├── products/     # CRUD produse
│       ├── cart/         # Gestionare coș
│       ├── orders/       # Gestionare comenzi
│       └── admin/        # Statistici admin
├── components/
│   └── Header.tsx        # Navigare
├── lib/
│   ├── prisma.ts         # Conexiune baza de date
│   └── auth.ts           # Configurare NextAuth
├── prisma/
│   ├── schema.prisma     # Schema baza de date
│   ├── seed.js           # Date inițiale
│   └── shopro.db         # Baza de date (creat la setup)
└── .env                  # Variabile de mediu
```

---

## Comenzi utile

```bash
npm run dev          # Pornește serverul de development
npm run db:seed      # Resetează și repopulează baza de date
npm run db:studio    # Interfață vizuală pentru baza de date
npm run build        # Build pentru producție
```

---

## Cerințe sistem

- Node.js 18+ (deja instalat)
- ~200MB spațiu disc (pentru node_modules)
- Windows 10/11

---

## Probleme comune

**Eroare la npm install:**
```bash
npm install --legacy-peer-deps
```

**Port 3000 ocupat:**
```bash
npm run dev -- -p 3001
# Accesează http://localhost:3001
```

**Resetează baza de date:**
```bash
# Șterge fișierul și recreeaza-l
del prisma\shopro.db
npm run db:push
npm run db:seed
```

---

## Pași următori pentru producție

Când ești gata să lansezi online, înlocuiești:
1. **SQLite → PostgreSQL** (Supabase gratuit sau Neon)
2. **Autentificare** → adaugă email de confirmare
3. **Plăți** → integrezi Stripe (cod deja pregătit în plan)
4. **Deploy** → Vercel (gratuit pentru Next.js)
