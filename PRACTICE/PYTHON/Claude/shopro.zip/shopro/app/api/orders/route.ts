import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 })

  const userId = (session.user as any).id
  const isAdmin = (session.user as any).role === 'admin'

  const orders = await prisma.order.findMany({
    where: isAdmin ? {} : { userId },
    include: {
      items: { include: { product: { select: { name: true, emoji: true } } } },
      user: { select: { name: true, email: true } },
    },
    orderBy: { createdAt: 'desc' },
  })
  return NextResponse.json(orders)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 })

  const userId = (session.user as any).id
  const { name, address, city, phone, notes } = await req.json()

  if (!name || !address || !city || !phone)
    return NextResponse.json({ error: 'Completează toate câmpurile de livrare' }, { status: 400 })

  // Get cart items
  const cartItems = await prisma.cartItem.findMany({
    where: { userId },
    include: { product: true },
  })
  if (cartItems.length === 0) return NextResponse.json({ error: 'Coșul este gol' }, { status: 400 })

  // Check stock
  for (const item of cartItems) {
    if (item.product.stock < item.qty)
      return NextResponse.json({ error: `Stoc insuficient pentru ${item.product.name}` }, { status: 400 })
  }

  const subtotal = cartItems.reduce((s, item) => s + item.product.price * item.qty, 0)
  const shipping = subtotal >= 200 ? 0 : 15
  const total = subtotal + shipping

  // Create order in transaction
  const order = await prisma.$transaction(async (tx) => {
    const order = await tx.order.create({
      data: {
        userId, name, address, city, phone, notes, total,
        items: {
          create: cartItems.map(item => ({
            productId: item.productId,
            qty: item.qty,
            price: item.product.price,
          })),
        },
      },
      include: { items: { include: { product: true } } },
    })

    // Update stock
    for (const item of cartItems) {
      await tx.product.update({
        where: { id: item.productId },
        data: { stock: { decrement: item.qty } },
      })
    }

    // Clear cart
    await tx.cartItem.deleteMany({ where: { userId } })

    return order
  })

  return NextResponse.json(order)
}
