import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

async function getUserId(req: NextRequest) {
  const session = await getServerSession(authOptions)
  return session ? (session.user as any).id : null
}

export async function GET(req: NextRequest) {
  const userId = await getUserId(req)
  if (!userId) return NextResponse.json({ items: [] })

  const items = await prisma.cartItem.findMany({
    where: { userId },
    include: { product: { include: { category: true } } },
    orderBy: { createdAt: 'asc' },
  })
  return NextResponse.json({ items })
}

export async function POST(req: NextRequest) {
  const userId = await getUserId(req)
  if (!userId) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 })

  const { productId, qty = 1 } = await req.json()
  const product = await prisma.product.findUnique({ where: { id: productId } })
  if (!product) return NextResponse.json({ error: 'Produs negăsit' }, { status: 404 })

  const existing = await prisma.cartItem.findUnique({ where: { userId_productId: { userId, productId } } })
  const newQty = (existing?.qty || 0) + qty
  if (newQty > product.stock) return NextResponse.json({ error: 'Stoc insuficient' }, { status: 400 })

  const item = await prisma.cartItem.upsert({
    where: { userId_productId: { userId, productId } },
    update: { qty: newQty },
    create: { userId, productId, qty },
    include: { product: true },
  })
  return NextResponse.json(item)
}

export async function PUT(req: NextRequest) {
  const userId = await getUserId(req)
  if (!userId) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 })

  const { productId, qty } = await req.json()
  if (qty <= 0) {
    await prisma.cartItem.delete({ where: { userId_productId: { userId, productId } } })
    return NextResponse.json({ deleted: true })
  }
  const item = await prisma.cartItem.update({
    where: { userId_productId: { userId, productId } },
    data: { qty },
    include: { product: true },
  })
  return NextResponse.json(item)
}

export async function DELETE(req: NextRequest) {
  const userId = await getUserId(req)
  if (!userId) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 })

  const { productId } = await req.json()
  if (productId) {
    await prisma.cartItem.delete({ where: { userId_productId: { userId, productId } } })
  } else {
    await prisma.cartItem.deleteMany({ where: { userId } })
  }
  return NextResponse.json({ success: true })
}
