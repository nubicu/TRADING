import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || (session.user as any).role !== 'admin')
    return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })

  const [totalProducts, totalOrders, totalUsers, orders] = await Promise.all([
    prisma.product.count({ where: { active: true } }),
    prisma.order.count(),
    prisma.user.count(),
    prisma.order.findMany({ select: { total: true, createdAt: true } }),
  ])

  const revenue = orders.reduce((s, o) => s + o.total, 0)
  const recentOrders = await prisma.order.findMany({
    take: 5,
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { name: true } }, items: true },
  })

  return NextResponse.json({ totalProducts, totalOrders, totalUsers, revenue, recentOrders })
}
