import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const category = searchParams.get('category')
  const search = searchParams.get('search')
  const minPrice = parseFloat(searchParams.get('minPrice') || '0')
  const maxPrice = parseFloat(searchParams.get('maxPrice') || '999999')
  const onSale = searchParams.get('onSale') === '1'
  const inStock = searchParams.get('inStock') === '1'
  const sort = searchParams.get('sort') || 'createdAt'
  const page = parseInt(searchParams.get('page') || '1')
  const limit = parseInt(searchParams.get('limit') || '96')

  const where: any = {
    active: true,
    price: { gte: minPrice, lte: maxPrice },
  }
  if (category) where.category = { name: category }
  if (search) where.OR = [
    { name: { contains: search, mode: 'insensitive' } },
    { description: { contains: search, mode: 'insensitive' } },
  ]
  if (onSale) where.oldPrice = { not: null }
  if (inStock) where.stock = { gt: 0 }

  let orderBy: any = { createdAt: 'desc' }
  if (sort === 'price-asc') orderBy = { price: 'asc' }
  else if (sort === 'price-desc') orderBy = { price: 'desc' }
  else if (sort === 'name') orderBy = { name: 'asc' }

  const [products, total] = await Promise.all([
    prisma.product.findMany({
      where, orderBy,
      skip: (page - 1) * limit,
      take: limit,
      include: {
        category: true,
        reviews: { select: { rating: true } },
      },
    }),
    prisma.product.count({ where }),
  ])

  const enriched = products.map(p => ({
    ...p,
    avgRating: p.reviews.length
      ? (p.reviews.reduce((s, r) => s + r.rating, 0) / p.reviews.length).toFixed(1)
      : null,
    reviewCount: p.reviews.length,
  }))

  return NextResponse.json({ products: enriched, total, pages: Math.ceil(total / limit) })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || (session.user as any).role !== 'admin')
    return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })

  const data = await req.json()
  const { name, description, price, oldPrice, stock, emoji, categoryId, isNew } = data
  if (!name || !price || !categoryId)
    return NextResponse.json({ error: 'Câmpuri lipsă' }, { status: 400 })

  const product = await prisma.product.create({
    data: {
      name, description: description || '',
      price: parseFloat(price),
      oldPrice: oldPrice ? parseFloat(oldPrice) : null,
      stock: parseInt(stock) || 0,
      emoji: emoji || '📦',
      isNew: isNew || false,
      categoryId,
    },
    include: { category: true },
  })
  return NextResponse.json(product)
}
