import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautentificat' }, { status: 401 })

  const userId = (session.user as any).id
  const { rating, comment } = await req.json()

  if (!rating || !comment?.trim())
    return NextResponse.json({ error: 'Rating și comentariu obligatorii' }, { status: 400 })
  if (rating < 1 || rating > 5)
    return NextResponse.json({ error: 'Rating invalid' }, { status: 400 })

  // Check if already reviewed
  const existing = await prisma.review.findUnique({
    where: { userId_productId: { userId, productId: params.id } }
  })
  if (existing)
    return NextResponse.json({ error: 'Ai lăsat deja o recenzie pentru acest produs' }, { status: 409 })

  const review = await prisma.review.create({
    data: { userId, productId: params.id, rating, comment: comment.trim() },
    include: { user: { select: { name: true } } }
  })
  return NextResponse.json(review)
}
