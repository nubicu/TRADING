'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react'
import Link from 'next/link'

interface CartItem {
  id: string; qty: number
  product: { id: string; name: string; price: number; emoji: string; stock: number; category: { name: string } }
}

export default function CartPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [items, setItems] = useState<CartItem[]>([])
  const [loading, setLoading] = useState(true)
  const [checkout, setCheckout] = useState(false)
  const [placing, setPlacing] = useState(false)
  const [toast, setToast] = useState('')

  // Checkout form
  const [form, setForm] = useState({ name: '', address: '', city: '', phone: '', notes: '' })

  useEffect(() => {
    if (status === 'unauthenticated') { router.push('/auth'); return }
    if (status === 'authenticated') {
      fetch('/api/cart').then(r => r.json()).then(d => { setItems(d.items || []); setLoading(false) })
      // Pre-fill name
      if (session?.user?.name) setForm(f => ({ ...f, name: session.user!.name! }))
    }
  }, [status, session])

  const updateQty = async (productId: string, qty: number) => {
    const res = await fetch('/api/cart', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, qty }),
    })
    if (res.ok) {
      setItems(prev => qty <= 0 ? prev.filter(i => i.product.id !== productId) : prev.map(i => i.product.id === productId ? { ...i, qty } : i))
      window.dispatchEvent(new Event('cartUpdated'))
    }
  }

  const removeItem = async (productId: string) => {
    await fetch('/api/cart', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId }),
    })
    setItems(prev => prev.filter(i => i.product.id !== productId))
    window.dispatchEvent(new Event('cartUpdated'))
  }

  const placeOrder = async (e: React.FormEvent) => {
    e.preventDefault()
    setPlacing(true)
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setPlacing(false)
    if (res.ok) {
      setItems([])
      window.dispatchEvent(new Event('cartUpdated'))
      router.push(`/orders?success=${data.id}`)
    } else {
      setToast(data.error || 'Eroare la plasarea comenzii')
      setTimeout(() => setToast(''), 3000)
    }
  }

  const subtotal = items.reduce((s, i) => s + i.product.price * i.qty, 0)
  const shipping = subtotal >= 200 ? 0 : 15
  const total = subtotal + shipping

  if (loading) return (
    <>
      <Header />
      <div className="flex items-center justify-center min-h-64">
        <div className="text-gray-400">Se încarcă...</div>
      </div>
    </>
  )

  return (
    <>
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/" className="text-gray-400 hover:text-gray-600 transition-colors"><ArrowLeft size={20} /></Link>
          <h1 className="font-display text-3xl font-black">Coșul tău</h1>
          <span className="text-gray-400 text-sm">({items.length} {items.length === 1 ? 'produs' : 'produse'})</span>
        </div>

        {items.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-6xl mb-4">🛒</div>
            <p className="text-lg text-gray-500 mb-6">Coșul tău este gol</p>
            <Link href="/">
              <button className="px-6 py-3 rounded-xl text-white font-semibold" style={{ background: 'var(--accent)' }}>
                Mergi la cumpărături
              </button>
            </Link>
          </div>
        ) : (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-3">
              {items.map(item => (
                <div key={item.id} className="bg-white rounded-2xl p-4 shadow-sm border flex items-center gap-4"
                     style={{ borderColor: 'var(--border)' }}>
                  <div className="w-14 h-14 rounded-xl flex items-center justify-center text-3xl flex-shrink-0"
                       style={{ background: 'var(--light)' }}>
                    {item.product.emoji}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{item.product.name}</p>
                    <p className="text-xs text-gray-400">{item.product.category.name}</p>
                    <p className="font-display font-bold text-base mt-1">{item.product.price} RON</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => updateQty(item.product.id, item.qty - 1)}
                      className="w-7 h-7 border rounded-lg flex items-center justify-center hover:bg-gray-50 transition-colors"
                      style={{ borderColor: 'var(--border)' }}>
                      <Minus size={12} />
                    </button>
                    <span className="w-6 text-center font-semibold text-sm">{item.qty}</span>
                    <button onClick={() => updateQty(item.product.id, item.qty + 1)}
                      disabled={item.qty >= item.product.stock}
                      className="w-7 h-7 border rounded-lg flex items-center justify-center hover:bg-gray-50 transition-colors disabled:opacity-30"
                      style={{ borderColor: 'var(--border)' }}>
                      <Plus size={12} />
                    </button>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-sm">{(item.product.price * item.qty).toFixed(0)} RON</p>
                    <button onClick={() => removeItem(item.product.id)} className="text-gray-300 hover:text-red-400 transition-colors mt-1">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary + Checkout */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-5 shadow-sm border sticky top-20" style={{ borderColor: 'var(--border)' }}>
                <h2 className="font-display font-bold text-lg mb-4">Sumar</h2>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-gray-500">Subtotal</span><span>{subtotal} RON</span></div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Transport</span>
                    <span style={{ color: shipping === 0 ? 'var(--success)' : undefined }}>
                      {shipping === 0 ? 'GRATUIT' : `${shipping} RON`}
                    </span>
                  </div>
                  {subtotal < 200 && (
                    <p className="text-xs text-gray-400 bg-gray-50 rounded-lg p-2">
                      🚚 Adaugă {(200 - subtotal).toFixed(0)} RON pentru transport gratuit
                    </p>
                  )}
                  <div className="flex justify-between font-bold text-base pt-2 border-t" style={{ borderColor: 'var(--border)' }}>
                    <span>Total</span>
                    <span style={{ color: 'var(--accent)' }}>{total} RON</span>
                  </div>
                </div>

                {!checkout ? (
                  <button onClick={() => setCheckout(true)}
                    className="w-full py-3.5 rounded-xl text-white font-bold mt-4 transition-all hover:opacity-90 flex items-center justify-center gap-2"
                    style={{ background: 'var(--accent)' }}>
                    <ShoppingBag size={16} /> Finalizează comanda
                  </button>
                ) : (
                  <form onSubmit={placeOrder} className="mt-4 space-y-3">
                    <p className="font-semibold text-sm">Date de livrare</p>
                    {[
                      { key: 'name', label: 'Nume complet', placeholder: 'Ion Popescu', type: 'text' },
                      { key: 'address', label: 'Adresă', placeholder: 'Str. Florilor 12, Ap. 4', type: 'text' },
                      { key: 'city', label: 'Oraș', placeholder: 'București', type: 'text' },
                      { key: 'phone', label: 'Telefon', placeholder: '0722 123 456', type: 'tel' },
                    ].map(f => (
                      <div key={f.key}>
                        <label className="text-xs text-gray-500 font-medium">{f.label}</label>
                        <input type={f.type} required placeholder={f.placeholder}
                          value={(form as any)[f.key]} onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                          className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none"
                          style={{ borderColor: 'var(--border)' }} />
                      </div>
                    ))}
                    <div>
                      <label className="text-xs text-gray-500 font-medium">Mențiuni (opțional)</label>
                      <textarea placeholder="Instrucțiuni livrare..."
                        value={form.notes} onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))}
                        className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none resize-none h-16"
                        style={{ borderColor: 'var(--border)' }} />
                    </div>
                    <div className="text-xs text-gray-400 bg-gray-50 rounded-lg p-2 text-center">
                      💳 Plata se face la livrare sau prin transfer bancar
                    </div>
                    <button type="submit" disabled={placing}
                      className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all hover:opacity-90 disabled:opacity-50"
                      style={{ background: 'var(--accent)' }}>
                      {placing ? 'Se plasează...' : `✅ Plasează comanda — ${total} RON`}
                    </button>
                    <button type="button" onClick={() => setCheckout(false)}
                      className="w-full py-2 text-xs text-gray-400 hover:text-gray-600">
                      ← Înapoi la coș
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {toast && (
        <div className="fixed bottom-5 right-5 z-50 px-5 py-3 rounded-xl text-white text-sm font-medium shadow-lg"
             style={{ background: 'var(--accent)' }}>
          {toast}
        </div>
      )}
    </>
  )
}
