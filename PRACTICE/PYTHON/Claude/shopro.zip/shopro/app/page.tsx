'use client'
import { useEffect, useState, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import Header from '@/components/Header'
import { Search, SlidersHorizontal, Star, ShoppingCart, X } from 'lucide-react'
import Link from 'next/link'

interface Product {
  id: string; name: string; description: string; price: number; oldPrice?: number
  stock: number; emoji: string; isNew: boolean; category: { name: string }
  avgRating: string | null; reviewCount: number
}

interface Category { id: string; name: string; emoji: string; _count: { products: number } }

export default function HomePage() {
  const { data: session } = useSession()
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [total, setTotal] = useState(0)
  const [loading, setLoading] = useState(true)
  const [addingId, setAddingId] = useState<string | null>(null)
  const [toast, setToast] = useState<{ msg: string; type: string } | null>(null)

  // Filters
  const [search, setSearch] = useState('')
  const [selectedCat, setSelectedCat] = useState('')
  const [minPrice, setMinPrice] = useState('')
  const [maxPrice, setMaxPrice] = useState('')
  const [onSale, setOnSale] = useState(false)
  const [inStock, setInStock] = useState(false)
  const [sort, setSort] = useState('createdAt')
  const [filtersOpen, setFiltersOpen] = useState(false)

  const showToast = (msg: string, type = 'success') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }

  const fetchProducts = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams()
    if (search) params.set('search', search)
    if (selectedCat) params.set('category', selectedCat)
    if (minPrice) params.set('minPrice', minPrice)
    if (maxPrice) params.set('maxPrice', maxPrice)
    if (onSale) params.set('onSale', '1')
    if (inStock) params.set('inStock', '1')
    params.set('sort', sort)

    const res = await fetch(`/api/products?${params}`)
    const data = await res.json()
    setProducts(data.products || [])
    setTotal(data.total || 0)
    setLoading(false)
  }, [search, selectedCat, minPrice, maxPrice, onSale, inStock, sort])

  useEffect(() => { fetchProducts() }, [fetchProducts])

  useEffect(() => {
    fetch('/api/products/categories').then(r => r.json()).then(setCategories)
  }, [])

  const addToCart = async (productId: string, productName: string) => {
    if (!session) { showToast('Autentifică-te pentru a adăuga în coș', 'error'); return }
    setAddingId(productId)
    const res = await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId, qty: 1 }),
    })
    const data = await res.json()
    setAddingId(null)
    if (res.ok) {
      showToast(`✅ ${productName} adăugat în coș!`)
      window.dispatchEvent(new Event('cartUpdated'))
    } else {
      showToast(data.error || 'Eroare', 'error')
    }
  }

  const clearFilters = () => {
    setSearch(''); setSelectedCat(''); setMinPrice(''); setMaxPrice('')
    setOnSale(false); setInStock(false); setSort('createdAt')
  }

  const hasFilters = search || selectedCat || minPrice || maxPrice || onSale || inStock

  return (
    <>
      <Header />

      {/* Hero */}
      <div className="relative overflow-hidden py-20 px-4 text-center text-white"
           style={{ background: 'linear-gradient(135deg, var(--ink) 0%, #16213e 60%, #0f3460 100%)' }}>
        <div className="absolute inset-0 pointer-events-none"
             style={{ background: 'radial-gradient(circle at 70% 50%, rgba(230,57,70,0.15) 0%, transparent 60%)' }} />
        <h1 className="font-display text-4xl md:text-6xl font-black leading-tight relative">
          Produse de <span style={{ color: 'var(--accent)' }}>calitate</span>,<br />livrate rapid
        </h1>
        <p className="mt-4 text-white/60 text-lg relative">{total} produse disponibile</p>

        {/* Search bar in hero */}
        <div className="relative mt-8 max-w-lg mx-auto">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Caută produse, categorii..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-11 pr-4 py-4 rounded-2xl text-gray-800 shadow-lg focus:outline-none focus:ring-2 text-base"
            style={{ '--tw-ring-color': 'var(--accent)' } as any}
          />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex gap-6">

          {/* Sidebar Filters - Desktop */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="bg-white rounded-2xl p-5 shadow-sm border sticky top-20" style={{ borderColor: 'var(--border)' }}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-display font-bold text-lg" style={{ color: 'var(--ink)' }}>Filtre</h2>
                {hasFilters && (
                  <button onClick={clearFilters} className="text-xs text-gray-400 hover:text-red-500 flex items-center gap-1">
                    <X size={12} /> Resetează
                  </button>
                )}
              </div>

              <div className="mb-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-3">Categorie</p>
                <button onClick={() => setSelectedCat('')}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm mb-1 transition-colors ${!selectedCat ? 'font-semibold text-white' : 'text-gray-600 hover:bg-gray-50'}`}
                  style={!selectedCat ? { background: 'var(--accent)' } : {}}>
                  Toate ({total})
                </button>
                {categories.map(cat => (
                  <button key={cat.id} onClick={() => setSelectedCat(cat.name)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-sm mb-1 transition-colors flex items-center justify-between ${selectedCat === cat.name ? 'font-semibold text-white' : 'text-gray-600 hover:bg-gray-50'}`}
                    style={selectedCat === cat.name ? { background: 'var(--accent)' } : {}}>
                    <span>{cat.emoji} {cat.name}</span>
                    <span className="text-xs opacity-60">{cat._count.products}</span>
                  </button>
                ))}
              </div>

              <div className="mb-5">
                <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-3">Preț (RON)</p>
                <div className="flex gap-2">
                  <input type="number" placeholder="Min" value={minPrice} onChange={e => setMinPrice(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
                  <input type="number" placeholder="Max" value={maxPrice} onChange={e => setMaxPrice(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-gray-400 mb-2">Disponibilitate</p>
                <label className="flex items-center gap-2 cursor-pointer text-sm">
                  <input type="checkbox" checked={inStock} onChange={e => setInStock(e.target.checked)}
                    className="w-4 h-4 rounded" style={{ accentColor: 'var(--accent)' }} />
                  În stoc
                </label>
                <label className="flex items-center gap-2 cursor-pointer text-sm">
                  <input type="checkbox" checked={onSale} onChange={e => setOnSale(e.target.checked)}
                    className="w-4 h-4 rounded" style={{ accentColor: 'var(--accent)' }} />
                  La reducere
                </label>
              </div>
            </div>
          </aside>

          {/* Products */}
          <main className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
              <p className="text-sm text-gray-500">
                {loading ? 'Se încarcă...' : `${products.length} produse găsite`}
              </p>
              <div className="flex items-center gap-2">
                <button onClick={() => setFiltersOpen(!filtersOpen)}
                  className="lg:hidden flex items-center gap-1 px-3 py-2 border rounded-lg text-sm"
                  style={{ borderColor: 'var(--border)' }}>
                  <SlidersHorizontal size={14} /> Filtre
                </button>
                <select value={sort} onChange={e => setSort(e.target.value)}
                  className="px-3 py-2 border rounded-lg text-sm bg-white focus:outline-none"
                  style={{ borderColor: 'var(--border)' }}>
                  <option value="createdAt">Implicit</option>
                  <option value="price-asc">Preț: Mic → Mare</option>
                  <option value="price-desc">Preț: Mare → Mic</option>
                  <option value="name">Nume A → Z</option>
                </select>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="bg-white rounded-xl h-72 animate-pulse" style={{ opacity: 0.5 }} />
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-20 text-gray-400">
                <div className="text-5xl mb-4">😔</div>
                <p className="text-lg">Niciun produs găsit</p>
                <button onClick={clearFilters} className="mt-4 px-5 py-2 rounded-lg text-white text-sm"
                        style={{ background: 'var(--accent)' }}>
                  Resetează filtrele
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                {products.map(p => (
                  <div key={p.id} className="bg-white rounded-xl shadow-sm border overflow-hidden group transition-all duration-200 hover:-translate-y-1 hover:shadow-md"
                       style={{ borderColor: 'var(--border)' }}>
                    <Link href={`/product/${p.id}`} className="block">
                      <div className="h-44 flex items-center justify-center relative"
                           style={{ background: 'linear-gradient(135deg, #f8f6f2, #ede9e3)' }}>
                        <span className="text-6xl transition-transform duration-200 group-hover:scale-110">{p.emoji}</span>
                        {p.oldPrice && (
                          <span className="absolute top-2 left-2 px-2 py-1 rounded-full text-white text-xs font-bold"
                                style={{ background: 'var(--accent)' }}>
                            -{Math.round((1 - p.price / p.oldPrice) * 100)}%
                          </span>
                        )}
                        {p.isNew && !p.oldPrice && (
                          <span className="absolute top-2 left-2 px-2 py-1 rounded-full text-white text-xs font-bold"
                                style={{ background: 'var(--accent2)' }}>
                            Nou
                          </span>
                        )}
                      </div>
                    </Link>
                    <div className="p-3">
                      <p className="text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: 'var(--accent2)' }}>
                        {p.category.name}
                      </p>
                      <Link href={`/product/${p.id}`}>
                        <p className="font-semibold text-sm mb-1 leading-tight line-clamp-2 hover:underline cursor-pointer">{p.name}</p>
                      </Link>
                      {p.avgRating && (
                        <div className="flex items-center gap-1 mb-2">
                          <Star size={11} fill="#f4a261" stroke="#f4a261" />
                          <span className="text-xs text-gray-500">{p.avgRating} ({p.reviewCount})</span>
                        </div>
                      )}
                      <div className="flex items-center justify-between mt-2">
                        <div>
                          <span className="font-display font-bold text-base">{p.price} RON</span>
                          {p.oldPrice && <div className="text-xs text-gray-400 line-through">{p.oldPrice} RON</div>}
                        </div>
                        {p.stock > 0 ? (
                          <button onClick={() => addToCart(p.id, p.name)} disabled={addingId === p.id}
                            className="w-9 h-9 rounded-lg flex items-center justify-center text-white transition-all hover:opacity-90 active:scale-95 disabled:opacity-50"
                            style={{ background: addingId === p.id ? 'var(--accent2)' : 'var(--ink)' }}>
                            {addingId === p.id ? '⏳' : <ShoppingCart size={15} />}
                          </button>
                        ) : (
                          <span className="text-xs text-gray-400">Indisponibil</span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </main>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-5 right-5 z-50 px-5 py-3 rounded-xl text-white text-sm font-medium shadow-lg transition-all
          ${toast.type === 'error' ? '' : ''}`}
          style={{ background: toast.type === 'error' ? 'var(--accent)' : 'var(--ink)' }}>
          {toast.msg}
        </div>
      )}
    </>
  )
}
