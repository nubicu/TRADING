'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useParams, useRouter } from 'next/navigation'
import Header from '@/components/Header'
import Link from 'next/link'
import { ArrowLeft, ShoppingCart, Star, StarHalf, Package, Truck, Shield, RotateCcw, Plus, Minus } from 'lucide-react'

interface Review {
  id: string
  rating: number
  comment: string
  createdAt: string
  user: { name: string }
}

interface Product {
  id: string
  name: string
  description: string
  price: number
  oldPrice: number | null
  stock: number
  emoji: string
  isNew: boolean
  active: boolean
  createdAt: string
  category: { name: string; emoji: string }
  reviews: Review[]
}

function StarRating({ rating, size = 16 }: { rating: number; size?: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          size={size}
          fill={i <= Math.round(rating) ? '#f4a261' : 'none'}
          stroke={i <= Math.round(rating) ? '#f4a261' : '#d1d5db'}
        />
      ))}
    </div>
  )
}

export default function ProductPage() {
  const { id } = useParams<{ id: string }>()
  const { data: session } = useSession()
  const router = useRouter()

  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [notFound, setNotFound] = useState(false)
  const [qty, setQty] = useState(1)
  const [adding, setAdding] = useState(false)
  const [toast, setToast] = useState<{ msg: string; type: string } | null>(null)

  // Review form
  const [reviewRating, setReviewRating] = useState(5)
  const [reviewComment, setReviewComment] = useState('')
  const [submittingReview, setSubmittingReview] = useState(false)
  const [hoverRating, setHoverRating] = useState(0)

  const showToast = (msg: string, type = 'success') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }

  useEffect(() => {
    fetch(`/api/products/${id}`)
      .then(r => {
        if (r.status === 404) { setNotFound(true); setLoading(false); return null }
        return r.json()
      })
      .then(data => {
        if (data) { setProduct(data); setLoading(false) }
      })
      .catch(() => { setNotFound(true); setLoading(false) })
  }, [id])

  const addToCart = async () => {
    if (!session) { showToast('Autentifică-te pentru a adăuga în coș', 'error'); return }
    if (!product) return
    setAdding(true)
    const res = await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ productId: product.id, qty }),
    })
    const data = await res.json()
    setAdding(false)
    if (res.ok) {
      showToast(`✅ ${product.name} adăugat în coș!`)
      window.dispatchEvent(new Event('cartUpdated'))
    } else {
      showToast(data.error || 'Eroare', 'error')
    }
  }

  const submitReview = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) { showToast('Autentifică-te pentru a lăsa o recenzie', 'error'); return }
    if (!reviewComment.trim()) { showToast('Scrie un comentariu', 'error'); return }
    setSubmittingReview(true)
    const res = await fetch(`/api/products/${id}/reviews`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rating: reviewRating, comment: reviewComment }),
    })
    const data = await res.json()
    setSubmittingReview(false)
    if (res.ok) {
      showToast('✅ Recenzia a fost adăugată!')
      setReviewComment('')
      setReviewRating(5)
      // Refresh product to show new review
      fetch(`/api/products/${id}`).then(r => r.json()).then(setProduct)
    } else {
      showToast(data.error || 'Eroare', 'error')
    }
  }

  if (loading) return (
    <>
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-10">
          <div className="bg-white rounded-2xl h-80 animate-pulse" style={{ opacity: 0.4 }} />
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl h-8 animate-pulse" style={{ opacity: 0.4, width: `${80 - i * 10}%` }} />
            ))}
          </div>
        </div>
      </div>
    </>
  )

  if (notFound || !product) return (
    <>
      <Header />
      <div className="text-center py-24">
        <div className="text-6xl mb-4">🔍</div>
        <h2 className="font-display text-2xl font-bold mb-2">Produs negăsit</h2>
        <p className="text-gray-400 mb-6">Produsul nu există sau a fost eliminat.</p>
        <Link href="/">
          <button className="px-6 py-3 rounded-xl text-white font-semibold" style={{ background: 'var(--accent)' }}>
            Înapoi la magazin
          </button>
        </Link>
      </div>
    </>
  )

  const avgRating = product.reviews.length
    ? product.reviews.reduce((s, r) => s + r.rating, 0) / product.reviews.length
    : 0
  const discount = product.oldPrice ? Math.round((1 - product.price / product.oldPrice) * 100) : 0

  return (
    <>
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-8">

        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6">
          <Link href="/" className="hover:text-gray-600 transition-colors">Magazin</Link>
          <span>/</span>
          <button onClick={() => router.push(`/?category=${product.category.name}`)}
            className="hover:text-gray-600 transition-colors">
            {product.category.emoji} {product.category.name}
          </button>
          <span>/</span>
          <span className="text-gray-700 font-medium truncate max-w-48">{product.name}</span>
        </nav>

        {/* Main product section */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">

          {/* Image / Emoji display */}
          <div className="relative">
            <div className="rounded-3xl flex items-center justify-center aspect-square relative overflow-hidden"
                 style={{ background: 'linear-gradient(135deg, #f8f6f2 0%, #ede9e3 100%)' }}>
              <span className="text-[8rem] select-none">{product.emoji}</span>

              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {discount > 0 && (
                  <span className="px-3 py-1.5 rounded-full text-white text-sm font-bold shadow"
                        style={{ background: 'var(--accent)' }}>
                    -{discount}% REDUCERE
                  </span>
                )}
                {product.isNew && !discount && (
                  <span className="px-3 py-1.5 rounded-full text-white text-sm font-bold shadow"
                        style={{ background: 'var(--accent2)' }}>
                    NOU
                  </span>
                )}
                {product.stock === 0 && (
                  <span className="px-3 py-1.5 rounded-full text-white text-sm font-bold shadow bg-gray-400">
                    EPUIZAT
                  </span>
                )}
              </div>
            </div>

            {/* Stock indicator */}
            {product.stock > 0 && product.stock <= 10 && (
              <div className="mt-3 text-center text-sm font-semibold" style={{ color: '#856404' }}>
                ⚠️ Ultimele {product.stock} bucăți în stoc!
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col">
            <p className="text-sm font-semibold uppercase tracking-wide mb-2" style={{ color: 'var(--accent2)' }}>
              {product.category.emoji} {product.category.name}
            </p>
            <h1 className="font-display text-3xl font-black leading-tight mb-3">{product.name}</h1>

            {/* Rating summary */}
            {product.reviews.length > 0 && (
              <div className="flex items-center gap-3 mb-4">
                <StarRating rating={avgRating} size={18} />
                <span className="font-semibold text-sm">{avgRating.toFixed(1)}</span>
                <span className="text-gray-400 text-sm">({product.reviews.length} {product.reviews.length === 1 ? 'recenzie' : 'recenzii'})</span>
              </div>
            )}

            {/* Price */}
            <div className="flex items-end gap-3 mb-5">
              <span className="font-display font-black text-4xl" style={{ color: 'var(--accent)' }}>
                {product.price} RON
              </span>
              {product.oldPrice && (
                <div className="flex flex-col">
                  <span className="text-gray-400 line-through text-lg">{product.oldPrice} RON</span>
                  <span className="text-xs font-bold" style={{ color: 'var(--success)' }}>
                    Economisești {(product.oldPrice - product.price).toFixed(0)} RON
                  </span>
                </div>
              )}
            </div>

            {/* Description */}
            {product.description && (
              <p className="text-gray-600 leading-relaxed mb-6 text-sm">{product.description}</p>
            )}

            {/* Qty + Add to cart */}
            {product.stock > 0 ? (
              <div className="flex items-center gap-3 mb-5">
                <div className="flex items-center border rounded-xl overflow-hidden" style={{ borderColor: 'var(--border)' }}>
                  <button onClick={() => setQty(q => Math.max(1, q - 1))}
                    className="px-4 py-3 hover:bg-gray-50 transition-colors text-gray-600">
                    <Minus size={14} />
                  </button>
                  <span className="px-4 py-3 font-semibold min-w-12 text-center border-x" style={{ borderColor: 'var(--border)' }}>
                    {qty}
                  </span>
                  <button onClick={() => setQty(q => Math.min(product.stock, q + 1))}
                    className="px-4 py-3 hover:bg-gray-50 transition-colors text-gray-600">
                    <Plus size={14} />
                  </button>
                </div>
                <button onClick={addToCart} disabled={adding}
                  className="flex-1 py-3 rounded-xl text-white font-bold flex items-center justify-center gap-2 transition-all hover:opacity-90 active:scale-95 disabled:opacity-50"
                  style={{ background: adding ? 'var(--accent2)' : 'var(--ink)' }}>
                  <ShoppingCart size={17} />
                  {adding ? 'Se adaugă...' : 'Adaugă în coș'}
                </button>
              </div>
            ) : (
              <div className="py-3 px-5 rounded-xl text-center text-gray-400 border mb-5 font-medium"
                   style={{ borderColor: 'var(--border)' }}>
                Momentan indisponibil
              </div>
            )}

            {/* Guarantees */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: Truck, text: 'Livrare 3-5 zile', sub: 'Gratuit peste 200 RON' },
                { icon: Shield, text: 'Garanție 1 an', sub: 'Conformitate produs' },
                { icon: RotateCcw, text: 'Retur 14 zile', sub: 'Fără întrebări' },
                { icon: Package, text: 'Ambalaj securizat', sub: 'Protecție transport' },
              ].map(({ icon: Icon, text, sub }) => (
                <div key={text} className="flex items-start gap-2 p-3 rounded-xl" style={{ background: 'var(--light)' }}>
                  <Icon size={16} className="flex-shrink-0 mt-0.5" style={{ color: 'var(--accent2)' }} />
                  <div>
                    <p className="text-xs font-semibold">{text}</p>
                    <p className="text-xs text-gray-400">{sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Reviews section */}
        <div className="border-t pt-10" style={{ borderColor: 'var(--border)' }}>
          <h2 className="font-display text-2xl font-black mb-6">
            Recenzii {product.reviews.length > 0 && <span className="text-gray-400 font-normal text-lg">({product.reviews.length})</span>}
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Reviews list */}
            <div>
              {product.reviews.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                  <Star size={40} className="mx-auto mb-3 opacity-30" />
                  <p>Fii primul care lasă o recenzie!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Rating summary bar */}
                  <div className="bg-white rounded-2xl p-5 border mb-5" style={{ borderColor: 'var(--border)' }}>
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="font-display font-black text-5xl">{avgRating.toFixed(1)}</p>
                        <StarRating rating={avgRating} size={14} />
                        <p className="text-xs text-gray-400 mt-1">{product.reviews.length} recenzii</p>
                      </div>
                      <div className="flex-1 space-y-1">
                        {[5, 4, 3, 2, 1].map(star => {
                          const count = product.reviews.filter(r => r.rating === star).length
                          const pct = product.reviews.length ? (count / product.reviews.length) * 100 : 0
                          return (
                            <div key={star} className="flex items-center gap-2 text-xs">
                              <span className="w-3 text-right text-gray-400">{star}</span>
                              <Star size={10} fill="#f4a261" stroke="#f4a261" />
                              <div className="flex-1 bg-gray-100 rounded-full h-1.5 overflow-hidden">
                                <div className="h-full rounded-full transition-all" style={{ width: `${pct}%`, background: '#f4a261' }} />
                              </div>
                              <span className="w-4 text-gray-400">{count}</span>
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  </div>

                  {product.reviews.map(review => (
                    <div key={review.id} className="bg-white rounded-2xl p-4 border" style={{ borderColor: 'var(--border)' }}>
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold flex-shrink-0"
                               style={{ background: 'var(--accent2)' }}>
                            {review.user.name.slice(0, 2).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-semibold text-sm">{review.user.name}</p>
                            <p className="text-xs text-gray-400">
                              {new Date(review.createdAt).toLocaleDateString('ro-RO', { day: '2-digit', month: 'long', year: 'numeric' })}
                            </p>
                          </div>
                        </div>
                        <StarRating rating={review.rating} size={13} />
                      </div>
                      <p className="text-sm text-gray-600 leading-relaxed">{review.comment}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Add review form */}
            <div>
              <div className="bg-white rounded-2xl p-6 border" style={{ borderColor: 'var(--border)' }}>
                <h3 className="font-display font-bold text-lg mb-4">Lasă o recenzie</h3>
                {!session ? (
                  <div className="text-center py-6">
                    <p className="text-gray-400 text-sm mb-3">Trebuie să fii autentificat pentru a lăsa o recenzie</p>
                    <Link href="/auth">
                      <button className="px-5 py-2.5 rounded-xl text-white text-sm font-semibold" style={{ background: 'var(--ink)' }}>
                        Autentifică-te
                      </button>
                    </Link>
                  </div>
                ) : (
                  <form onSubmit={submitReview} className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Rating</label>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map(star => (
                          <button key={star} type="button"
                            onClick={() => setReviewRating(star)}
                            onMouseEnter={() => setHoverRating(star)}
                            onMouseLeave={() => setHoverRating(0)}
                            className="transition-transform hover:scale-110">
                            <Star
                              size={28}
                              fill={(hoverRating || reviewRating) >= star ? '#f4a261' : 'none'}
                              stroke={(hoverRating || reviewRating) >= star ? '#f4a261' : '#d1d5db'}
                            />
                          </button>
                        ))}
                        <span className="ml-2 text-sm text-gray-400 self-center">
                          {['', 'Slab', 'Acceptabil', 'Bun', 'Foarte bun', 'Excelent'][hoverRating || reviewRating]}
                        </span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-2">Comentariu</label>
                      <textarea
                        value={reviewComment}
                        onChange={e => setReviewComment(e.target.value)}
                        rows={4}
                        placeholder="Descrie experiența ta cu acest produs..."
                        required
                        className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none resize-none"
                        style={{ borderColor: 'var(--border)' }}
                      />
                    </div>
                    <button type="submit" disabled={submittingReview}
                      className="w-full py-3 rounded-xl text-white font-bold text-sm transition-all hover:opacity-90 disabled:opacity-50"
                      style={{ background: 'var(--accent)' }}>
                      {submittingReview ? 'Se trimite...' : '⭐ Trimite recenzia'}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {toast && (
        <div className="fixed bottom-5 right-5 z-50 px-5 py-3 rounded-xl text-white text-sm font-medium shadow-lg"
             style={{ background: toast.type === 'error' ? 'var(--accent)' : 'var(--ink)' }}>
          {toast.msg}
        </div>
      )}
    </>
  )
}
