'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function AuthPage() {
  const router = useRouter()
  const [tab, setTab] = useState<'login' | 'register'>('login')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Login state
  const [loginEmail, setLoginEmail] = useState('admin@shopro.ro')
  const [loginPass, setLoginPass] = useState('admin123')

  // Register state
  const [regName, setRegName] = useState('')
  const [regEmail, setRegEmail] = useState('')
  const [regPass, setRegPass] = useState('')
  const [regPass2, setRegPass2] = useState('')

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true); setError('')
    const result = await signIn('credentials', {
      email: loginEmail, password: loginPass, redirect: false,
    })
    setLoading(false)
    if (result?.ok) router.push('/')
    else setError('Email sau parolă incorectă')
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    if (regPass !== regPass2) { setError('Parolele nu coincid'); return }
    if (regPass.length < 6) { setError('Parola trebuie să aibă minim 6 caractere'); return }
    setLoading(true); setError('')
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: regName, email: regEmail, password: regPass }),
    })
    const data = await res.json()
    if (!res.ok) { setError(data.error || 'Eroare la înregistrare'); setLoading(false); return }
    // Auto login
    await signIn('credentials', { email: regEmail, password: regPass, redirect: false })
    router.push('/')
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4"
         style={{ background: 'linear-gradient(135deg, var(--light) 0%, var(--cream) 100%)' }}>
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-xl p-8 border" style={{ borderColor: 'var(--border)' }}>
          <Link href="/">
            <div className="font-display text-3xl font-black text-center mb-2">
              Shop<span style={{ color: 'var(--accent)' }}>RO</span>
            </div>
          </Link>
          <p className="text-center text-gray-400 text-sm mb-6">Bun venit! Autentifică-te sau creează un cont.</p>

          {/* Tabs */}
          <div className="flex rounded-xl p-1 mb-6" style={{ background: 'var(--light)' }}>
            {(['login', 'register'] as const).map(t => (
              <button key={t} onClick={() => { setTab(t); setError('') }}
                className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${tab === t ? 'bg-white shadow text-gray-800' : 'text-gray-500'}`}>
                {t === 'login' ? 'Autentificare' : 'Înregistrare'}
              </button>
            ))}
          </div>

          {error && (
            <div className="mb-4 px-4 py-3 rounded-xl text-sm text-white" style={{ background: 'var(--accent)' }}>
              {error}
            </div>
          )}

          {tab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Email</label>
                <input type="email" value={loginEmail} onChange={e => setLoginEmail(e.target.value)}
                  required placeholder="email@exemplu.ro"
                  className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2"
                  style={{ borderColor: 'var(--border)', '--tw-ring-color': 'var(--accent2)' } as any} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Parolă</label>
                <input type="password" value={loginPass} onChange={e => setLoginPass(e.target.value)}
                  required placeholder="••••••••"
                  className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2"
                  style={{ borderColor: 'var(--border)', '--tw-ring-color': 'var(--accent2)' } as any} />
              </div>
              <button type="submit" disabled={loading}
                className="w-full py-3.5 rounded-xl text-white font-bold text-sm transition-all hover:opacity-90 disabled:opacity-50 mt-2"
                style={{ background: 'var(--ink)' }}>
                {loading ? 'Se încarcă...' : 'Intră în cont'}
              </button>
              <div className="text-center text-xs text-gray-400 bg-gray-50 rounded-lg p-3">
                🔑 Test: <strong>admin@shopro.ro</strong> / admin123 &nbsp;|&nbsp; <strong>client@shopro.ro</strong> / client123
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Nume complet</label>
                <input type="text" value={regName} onChange={e => setRegName(e.target.value)}
                  required placeholder="Ion Popescu"
                  className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none"
                  style={{ borderColor: 'var(--border)' }} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Email</label>
                <input type="email" value={regEmail} onChange={e => setRegEmail(e.target.value)}
                  required placeholder="email@exemplu.ro"
                  className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none"
                  style={{ borderColor: 'var(--border)' }} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Parolă</label>
                <input type="password" value={regPass} onChange={e => setRegPass(e.target.value)}
                  required placeholder="Minim 6 caractere"
                  className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none"
                  style={{ borderColor: 'var(--border)' }} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">Confirmă parola</label>
                <input type="password" value={regPass2} onChange={e => setRegPass2(e.target.value)}
                  required placeholder="Repetă parola"
                  className="w-full px-4 py-3 border rounded-xl text-sm focus:outline-none"
                  style={{ borderColor: 'var(--border)' }} />
              </div>
              <button type="submit" disabled={loading}
                className="w-full py-3.5 rounded-xl text-white font-bold text-sm transition-all hover:opacity-90 disabled:opacity-50"
                style={{ background: 'var(--ink)' }}>
                {loading ? 'Se creează contul...' : 'Creează cont'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  )
}
