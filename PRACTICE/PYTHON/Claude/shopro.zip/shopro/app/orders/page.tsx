'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import Header from '@/components/Header'
import Link from 'next/link'

const STATUS_COLORS: Record<string, string> = {
  'Plasata': '#856404',
  'Confirmata': 'var(--accent2)',
  'In procesare': 'var(--accent2)',
  'Expediata': '#0d6efd',
  'Finalizata': 'var(--success)',
  'Anulata': 'var(--accent)',
}
const STATUS_BG: Record<string, string> = {
  'Plasata': '#fff3cd',
  'Confirmata': '#cfe2ff',
  'In procesare': '#cfe2ff',
  'Expediata': '#cfe2ff',
  'Finalizata': '#d8f3dc',
  'Anulata': '#f8d7da',
}

export default function OrdersPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const searchParams = useSearchParams()
  const successId = searchParams.get('success')
  const [orders, setOrders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') { router.push('/auth'); return }
    if (status === 'authenticated') {
      fetch('/api/orders').then(r => r.json()).then(d => { setOrders(d); setLoading(false) })
    }
  }, [status])

  return (
    <>
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-8">
        {successId && (
          <div className="mb-6 p-5 rounded-2xl text-center" style={{ background: '#d8f3dc' }}>
            <div className="text-4xl mb-2">🎉</div>
            <h2 className="font-display font-bold text-xl" style={{ color: 'var(--success)' }}>Comandă plasată cu succes!</h2>
            <p className="text-sm text-gray-600 mt-1">Îți mulțumim! Vei fi contactat în curând pentru confirmare.</p>
            <p className="text-xs text-gray-400 mt-1">ID comandă: {successId.slice(0, 8).toUpperCase()}</p>
          </div>
        )}

        <h1 className="font-display text-3xl font-black mb-6">Comenzile mele</h1>

        {loading ? (
          <div className="text-center py-12 text-gray-400">Se încarcă...</div>
        ) : orders.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-5xl mb-4">📦</div>
            <p className="text-gray-500 mb-4">Nu ai plasat nicio comandă încă</p>
            <Link href="/"><button className="px-6 py-3 rounded-xl text-white font-semibold" style={{ background: 'var(--accent)' }}>
              Mergi la cumpărături
            </button></Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map(order => (
              <div key={order.id} className="bg-white rounded-2xl p-5 shadow-sm border" style={{ borderColor: 'var(--border)' }}>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <p className="font-semibold text-sm">#{order.id.slice(0, 8).toUpperCase()}</p>
                    <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString('ro-RO', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
                    <p className="text-xs text-gray-400 mt-0.5">📍 {order.city} · 📞 {order.phone}</p>
                  </div>
                  <div className="text-right">
                    <span className="px-3 py-1 rounded-full text-xs font-semibold"
                          style={{ background: STATUS_BG[order.status] || '#f0f0f0', color: STATUS_COLORS[order.status] || '#333' }}>
                      {order.status}
                    </span>
                    <p className="font-display font-bold text-base mt-2" style={{ color: 'var(--accent)' }}>{order.total} RON</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  {order.items.map((item: any) => (
                    <div key={item.id} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs"
                         style={{ background: 'var(--light)' }}>
                      <span>{item.product.emoji}</span>
                      <span className="font-medium">{item.product.name}</span>
                      <span className="text-gray-400">×{item.qty}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  )
}
