'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Header from '@/components/Header'
import { Package, ShoppingBag, Users, TrendingUp, Plus, Edit2, Trash2 } from 'lucide-react'

const STATUS_OPTIONS = ['Plasata', 'Confirmata', 'In procesare', 'Expediata', 'Finalizata', 'Anulata']

export default function AdminPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [section, setSection] = useState('dashboard')
  const [stats, setStats] = useState<any>(null)
  const [products, setProducts] = useState<any[]>([])
  const [orders, setOrders] = useState<any[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [modal, setModal] = useState(false)
  const [editProduct, setEditProduct] = useState<any>(null)
  const [form, setForm] = useState({ name: '', description: '', price: '', oldPrice: '', stock: '', emoji: '📦', categoryId: '', isNew: false, active: true })
  const [saving, setSaving] = useState(false)
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (status === 'unauthenticated') { router.push('/auth'); return }
    if (status === 'authenticated') {
      const user = session?.user as any
      if (user?.role !== 'admin') { router.push('/'); return }
      loadData()
    }
  }, [status])

  const loadData = async () => {
    const [statsRes, prodsRes, ordersRes, catsRes] = await Promise.all([
      fetch('/api/admin/stats'), fetch('/api/products?limit=200'),
      fetch('/api/orders'), fetch('/api/products/categories'),
    ])
    const [statsD, prodsD, ordersD, catsD] = await Promise.all([statsRes.json(), prodsRes.json(), ordersRes.json(), catsRes.json()])
    setStats(statsD); setProducts(prodsD.products || []); setOrders(ordersD); setCategories(catsD)
  }

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000) }

  const openNew = () => {
    setEditProduct(null)
    setForm({ name: '', description: '', price: '', oldPrice: '', stock: '', emoji: '📦', categoryId: categories[0]?.id || '', isNew: false, active: true })
    setModal(true)
  }

  const openEdit = (p: any) => {
    setEditProduct(p)
    setForm({ name: p.name, description: p.description, price: String(p.price), oldPrice: p.oldPrice ? String(p.oldPrice) : '', stock: String(p.stock), emoji: p.emoji, categoryId: p.categoryId, isNew: p.isNew, active: p.active })
    setModal(true)
  }

  const saveProduct = async () => {
    setSaving(true)
    const method = editProduct ? 'PUT' : 'POST'
    const url = editProduct ? `/api/products/${editProduct.id}` : '/api/products'
    const res = await fetch(url, {
      method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
    })
    setSaving(false)
    if (res.ok) {
      showToast(editProduct ? '✅ Produs actualizat!' : '✅ Produs adăugat!')
      setModal(false); loadData()
    } else {
      const d = await res.json(); showToast('❌ ' + (d.error || 'Eroare'))
    }
  }

  const deleteProduct = async (id: string) => {
    if (!confirm('Șterge produsul?')) return
    await fetch(`/api/products/${id}`, { method: 'DELETE' })
    showToast('🗑️ Produs șters'); loadData()
  }

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    await fetch(`/api/orders/${orderId}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: newStatus }),
    })
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: newStatus } : o))
    showToast('✅ Status actualizat')
  }

  const navItems = [
    { key: 'dashboard', icon: TrendingUp, label: 'Dashboard' },
    { key: 'products', icon: Package, label: 'Produse' },
    { key: 'orders', icon: ShoppingBag, label: 'Comenzi' },
    { key: 'users', icon: Users, label: 'Utilizatori' },
  ]

  if (status === 'loading') return <><Header /><div className="flex items-center justify-center min-h-64 text-gray-400">Se încarcă...</div></>

  return (
    <>
      <Header />
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <nav className="w-52 flex-shrink-0 hidden md:block" style={{ background: 'var(--ink)' }}>
          <div className="p-4">
            <p className="text-xs font-semibold uppercase tracking-wider text-white/40 mb-3">Admin Panel</p>
            {navItems.map(item => (
              <button key={item.key} onClick={() => setSection(item.key)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm mb-1 transition-all
                  ${section === item.key ? 'text-white font-semibold' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
                style={section === item.key ? { background: 'rgba(230,57,70,0.2)', borderLeft: '3px solid var(--accent)' } : {}}>
                <item.icon size={16} />
                {item.label}
              </button>
            ))}
          </div>
          <div className="p-4 border-t border-white/10 mt-4">
            <a href="/" className="flex items-center gap-2 text-sm text-white/50 hover:text-white/80 transition-colors">
              ← Magazin
            </a>
          </div>
        </nav>

        {/* Content */}
        <main className="flex-1 p-6 overflow-auto" style={{ background: 'var(--cream)' }}>
          {/* Mobile nav */}
          <div className="md:hidden flex gap-2 mb-4 flex-wrap">
            {navItems.map(item => (
              <button key={item.key} onClick={() => setSection(item.key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${section === item.key ? 'text-white' : 'bg-white text-gray-600 border'}`}
                style={section === item.key ? { background: 'var(--accent)' } : { borderColor: 'var(--border)' }}>
                {item.label}
              </button>
            ))}
          </div>

          {/* DASHBOARD */}
          {section === 'dashboard' && stats && (
            <div>
              <h1 className="font-display text-2xl font-black mb-1">Dashboard</h1>
              <p className="text-gray-400 text-sm mb-6">Bun venit, {(session?.user as any)?.name}!</p>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Produse', value: stats.totalProducts, icon: '📦', color: 'var(--accent2)' },
                  { label: 'Comenzi', value: stats.totalOrders, icon: '🛍️', color: 'var(--accent)' },
                  { label: 'Utilizatori', value: stats.totalUsers, icon: '👥', color: 'var(--success)' },
                  { label: 'Venituri (RON)', value: stats.revenue.toFixed(0), icon: '💰', color: '#f4a261' },
                ].map(s => (
                  <div key={s.label} className="bg-white rounded-2xl p-4 shadow-sm border" style={{ borderColor: 'var(--border)' }}>
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">{s.label}</p>
                    <div className="flex items-end justify-between mt-2">
                      <p className="font-display font-bold text-2xl">{s.value}</p>
                      <span className="text-2xl">{s.icon}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="bg-white rounded-2xl p-5 shadow-sm border" style={{ borderColor: 'var(--border)' }}>
                <h2 className="font-semibold mb-4">Ultimele comenzi</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="text-left text-xs text-gray-400 uppercase border-b" style={{ borderColor: 'var(--border)' }}>
                      <th className="pb-2">ID</th><th className="pb-2">Client</th><th className="pb-2">Total</th><th className="pb-2">Status</th>
                    </tr></thead>
                    <tbody>
                      {stats.recentOrders.map((o: any) => (
                        <tr key={o.id} className="border-b" style={{ borderColor: 'var(--border)' }}>
                          <td className="py-2 font-mono text-xs text-gray-400">{o.id.slice(0, 8).toUpperCase()}</td>
                          <td className="py-2 font-medium">{o.user.name}</td>
                          <td className="py-2 font-bold">{o.total} RON</td>
                          <td className="py-2"><span className="px-2 py-0.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700">{o.status}</span></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* PRODUCTS */}
          {section === 'products' && (
            <div>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h1 className="font-display text-2xl font-black">Produse</h1>
                  <p className="text-gray-400 text-sm">{products.length} produse în catalog</p>
                </div>
                <button onClick={openNew}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-white text-sm font-semibold transition-all hover:opacity-90"
                  style={{ background: 'var(--accent)' }}>
                  <Plus size={15} /> Adaugă produs
                </button>
              </div>
              <div className="bg-white rounded-2xl shadow-sm border overflow-hidden" style={{ borderColor: 'var(--border)' }}>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead><tr className="text-left text-xs text-gray-400 uppercase bg-gray-50 border-b" style={{ borderColor: 'var(--border)' }}>
                      <th className="px-4 py-3">Produs</th><th className="px-4 py-3">Categorie</th>
                      <th className="px-4 py-3">Preț</th><th className="px-4 py-3">Stoc</th><th className="px-4 py-3">Acțiuni</th>
                    </tr></thead>
                    <tbody>
                      {products.slice(0, 50).map(p => (
                        <tr key={p.id} className="border-b hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border)' }}>
                          <td className="px-4 py-3 flex items-center gap-2">
                            <span className="text-xl">{p.emoji}</span>
                            <span className="font-medium">{p.name}</span>
                          </td>
                          <td className="px-4 py-3 text-gray-500">{p.category.name}</td>
                          <td className="px-4 py-3 font-bold">
                            {p.price} RON
                            {p.oldPrice && <span className="text-xs text-gray-400 line-through ml-1">{p.oldPrice}</span>}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${p.stock > 10 ? 'bg-green-100 text-green-700' : p.stock > 0 ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'}`}>
                              {p.stock > 0 ? p.stock : 'Epuizat'}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-1">
                              <button onClick={() => openEdit(p)} className="p-1.5 rounded-lg hover:bg-blue-50 text-gray-400 hover:text-blue-600 transition-colors">
                                <Edit2 size={14} />
                              </button>
                              <button onClick={() => deleteProduct(p.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 transition-colors">
                                <Trash2 size={14} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {products.length > 50 && <p className="text-center text-xs text-gray-400 py-3">Se afișează primele 50 din {products.length}</p>}
              </div>
            </div>
          )}

          {/* ORDERS */}
          {section === 'orders' && (
            <div>
              <h1 className="font-display text-2xl font-black mb-1">Comenzi</h1>
              <p className="text-gray-400 text-sm mb-6">{orders.length} comenzi totale</p>
              <div className="space-y-3">
                {orders.map(order => (
                  <div key={order.id} className="bg-white rounded-2xl p-4 shadow-sm border" style={{ borderColor: 'var(--border)' }}>
                    <div className="flex items-start justify-between flex-wrap gap-3">
                      <div>
                        <p className="font-mono text-xs text-gray-400">#{order.id.slice(0, 8).toUpperCase()}</p>
                        <p className="font-semibold">{order.user.name}</p>
                        <p className="text-xs text-gray-400">{order.city} · {new Date(order.createdAt).toLocaleDateString('ro-RO')}</p>
                        <div className="flex flex-wrap gap-1.5 mt-2">
                          {order.items.map((item: any) => (
                            <span key={item.id} className="px-2 py-0.5 rounded-lg text-xs" style={{ background: 'var(--light)' }}>
                              {item.product.emoji} {item.product.name} ×{item.qty}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="text-right flex flex-col items-end gap-2">
                        <p className="font-display font-bold text-lg">{order.total} RON</p>
                        <select value={order.status} onChange={e => updateOrderStatus(order.id, e.target.value)}
                          className="px-2 py-1 border rounded-lg text-xs font-semibold focus:outline-none"
                          style={{ borderColor: 'var(--border)' }}>
                          {STATUS_OPTIONS.map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* USERS placeholder */}
          {section === 'users' && (
            <div>
              <h1 className="font-display text-2xl font-black mb-6">Utilizatori</h1>
              <p className="text-gray-400 text-sm">Secțiunea utilizatori afișează datele din baza de date. Conturile sunt gestionate prin înregistrare directă.</p>
            </div>
          )}
        </main>
      </div>

      {/* Product Modal */}
      {modal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md max-h-screen overflow-y-auto shadow-2xl">
            <h2 className="font-display font-bold text-xl mb-4">{editProduct ? '✏️ Editează produs' : '➕ Produs nou'}</h2>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-gray-500 font-medium">Nume *</label>
                <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Nume produs"
                  className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-500 font-medium">Categorie *</label>
                  <select value={form.categoryId} onChange={e => setForm(f => ({ ...f, categoryId: e.target.value }))}
                    className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none bg-white" style={{ borderColor: 'var(--border)' }}>
                    {categories.map(c => <option key={c.id} value={c.id}>{c.emoji} {c.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium">Emoji</label>
                  <input value={form.emoji} onChange={e => setForm(f => ({ ...f, emoji: e.target.value }))} maxLength={4}
                    className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-gray-500 font-medium">Preț (RON) *</label>
                  <input type="number" value={form.price} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} placeholder="99.99"
                    className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium">Preț vechi</label>
                  <input type="number" value={form.oldPrice} onChange={e => setForm(f => ({ ...f, oldPrice: e.target.value }))} placeholder="Opțional"
                    className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
                </div>
              </div>
              <div>
                <label className="text-xs text-gray-500 font-medium">Stoc *</label>
                <input type="number" value={form.stock} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} placeholder="50"
                  className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none" style={{ borderColor: 'var(--border)' }} />
              </div>
              <div>
                <label className="text-xs text-gray-500 font-medium">Descriere</label>
                <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={2}
                  className="w-full mt-1 px-3 py-2 border rounded-lg text-sm focus:outline-none resize-none" style={{ borderColor: 'var(--border)' }} />
              </div>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={form.isNew} onChange={e => setForm(f => ({ ...f, isNew: e.target.checked }))} />
                Produs nou
              </label>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => setModal(false)} className="flex-1 py-2.5 border rounded-xl text-sm font-semibold hover:bg-gray-50" style={{ borderColor: 'var(--border)' }}>
                Anulează
              </button>
              <button onClick={saveProduct} disabled={saving}
                className="flex-1 py-2.5 rounded-xl text-white text-sm font-semibold transition-all hover:opacity-90 disabled:opacity-50"
                style={{ background: 'var(--accent)' }}>
                {saving ? 'Se salvează...' : '💾 Salvează'}
              </button>
            </div>
          </div>
        </div>
      )}

      {toast && (
        <div className="fixed bottom-5 right-5 z-50 px-5 py-3 rounded-xl text-white text-sm font-medium shadow-lg"
             style={{ background: 'var(--ink)' }}>
          {toast}
        </div>
      )}
    </>
  )
}
