'use client'
import { useSession, signOut } from 'next-auth/react'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { ShoppingCart, User, LogOut, Settings, Menu, X } from 'lucide-react'

export default function Header() {
  const { data: session } = useSession()
  const [cartCount, setCartCount] = useState(0)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    if (!session) { setCartCount(0); return }
    fetch('/api/cart')
      .then(r => r.json())
      .then(d => setCartCount(d.items?.reduce((s: number, i: any) => s + i.qty, 0) || 0))
      .catch(() => {})

    // Listen for cart updates
    const handler = () => {
      fetch('/api/cart')
        .then(r => r.json())
        .then(d => setCartCount(d.items?.reduce((s: number, i: any) => s + i.qty, 0) || 0))
        .catch(() => {})
    }
    window.addEventListener('cartUpdated', handler)
    return () => window.removeEventListener('cartUpdated', handler)
  }, [session])

  const user = session?.user as any

  return (
    <header style={{ background: 'var(--ink)' }} className="sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="font-display text-2xl font-black text-white tracking-tight">
          Shop<span style={{ color: 'var(--accent)' }}>RO</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-2">
          <Link href="/" className="text-white/70 hover:text-white px-3 py-2 rounded-lg text-sm transition-colors hover:bg-white/10">
            Magazin
          </Link>
          {session ? (
            <>
              <Link href="/orders" className="text-white/70 hover:text-white px-3 py-2 rounded-lg text-sm transition-colors hover:bg-white/10">
                Comenzile mele
              </Link>
              {user?.role === 'admin' && (
                <Link href="/admin" className="text-white/70 hover:text-white px-3 py-2 rounded-lg text-sm transition-colors hover:bg-white/10">
                  ⚙️ Admin
                </Link>
              )}
              <div className="flex items-center gap-2 pl-2">
                <div className="flex items-center gap-2 text-white/80 text-sm">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold"
                       style={{ background: 'var(--accent2)' }}>
                    {user?.name?.slice(0, 2).toUpperCase()}
                  </div>
                  <span className="hidden lg:block">{user?.name?.split(' ')[0]}</span>
                </div>
                <button onClick={() => signOut({ callbackUrl: '/' })}
                  className="text-white/60 hover:text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
                  title="Ieșire">
                  <LogOut size={16} />
                </button>
              </div>
            </>
          ) : (
            <Link href="/auth" className="text-white/70 hover:text-white px-3 py-2 rounded-lg text-sm transition-colors hover:bg-white/10 flex items-center gap-1">
              <User size={16} /> Autentificare
            </Link>
          )}
          <Link href="/cart" className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all hover:opacity-90 relative"
                style={{ background: 'var(--accent)' }}>
            <ShoppingCart size={16} />
            Coș
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ background: 'white', color: 'var(--accent)' }}>
                {cartCount}
              </span>
            )}
          </Link>
        </nav>

        {/* Mobile */}
        <div className="flex md:hidden items-center gap-2">
          <Link href="/cart" className="relative p-2 text-white">
            <ShoppingCart size={22} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold"
                    style={{ background: 'var(--accent)', color: 'white' }}>
                {cartCount}
              </span>
            )}
          </Link>
          <button className="text-white p-2" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden border-t border-white/10 px-4 py-3 flex flex-col gap-1" style={{ background: 'var(--ink)' }}>
          <Link href="/" className="text-white/80 py-2 text-sm" onClick={() => setMenuOpen(false)}>Magazin</Link>
          {session ? (
            <>
              <Link href="/orders" className="text-white/80 py-2 text-sm" onClick={() => setMenuOpen(false)}>Comenzile mele</Link>
              {user?.role === 'admin' && <Link href="/admin" className="text-white/80 py-2 text-sm" onClick={() => setMenuOpen(false)}>Admin</Link>}
              <button onClick={() => signOut({ callbackUrl: '/' })} className="text-left text-white/60 py-2 text-sm">Ieșire</button>
            </>
          ) : (
            <Link href="/auth" className="text-white/80 py-2 text-sm" onClick={() => setMenuOpen(false)}>Autentificare</Link>
          )}
        </div>
      )}
    </header>
  )
}
