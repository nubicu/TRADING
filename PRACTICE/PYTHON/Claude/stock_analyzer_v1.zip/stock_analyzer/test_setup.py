#!/usr/bin/env python3
"""
Test Setup Script - Stock Market Analyzer
Verifică că toate dependințele și configurările sunt corecte
"""

import sys
import os

def print_header(text):
    print("\n" + "="*60)
    print(f"  {text}")
    print("="*60)

def check_python_version():
    """Verifică versiunea Python"""
    print_header("Checking Python Version")
    
    version = sys.version_info
    print(f"Python version: {version.major}.{version.minor}.{version.micro}")
    
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print("❌ ERROR: Python 3.8+ required")
        return False
    
    print("✅ Python version OK")
    return True

def check_dependencies():
    """Verifică dependințele Python"""
    print_header("Checking Dependencies")
    
    required_packages = [
        'flask',
        'flask_sqlalchemy',
        'apscheduler',
        'requests',
        'pandas',
        'numpy',
        'textblob',
        'pytz'
    ]
    
    missing = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package} - MISSING")
            missing.append(package)
    
    if missing:
        print(f"\n❌ Missing packages: {', '.join(missing)}")
        print("Run: pip install -r requirements.txt")
        return False
    
    print("\n✅ All dependencies installed")
    return True

def check_file_structure():
    """Verifică structura fișierelor"""
    print_header("Checking File Structure")
    
    required_files = [
        'app.py',
        'models.py',
        'analyzer.py',
        'data_fetcher.py',
        'scheduler.py',
        'requirements.txt',
        'templates/index.html',
        'templates/stock_detail.html',
        'templates/settings.html',
        'static/css/style.css',
        'static/js/main.js'
    ]
    
    missing = []
    
    for file in required_files:
        if os.path.exists(file):
            print(f"✅ {file}")
        else:
            print(f"❌ {file} - MISSING")
            missing.append(file)
    
    if missing:
        print(f"\n❌ Missing files: {', '.join(missing)}")
        return False
    
    print("\n✅ All files present")
    return True

def test_database():
    """Testează inițializarea bazei de date"""
    print_header("Testing Database")
    
    try:
        from app import app, db, Stock
        
        with app.app_context():
            # Try to create tables
            db.create_all()
            print("✅ Database tables created")
            
            # Check stock count
            count = Stock.query.count()
            print(f"✅ Current stocks in database: {count}")
            
            if count == 0:
                print("ℹ️  Database is empty - run the app to populate")
        
        return True
        
    except Exception as e:
        print(f"❌ Database error: {str(e)}")
        return False

def test_imports():
    """Testează importurile principale"""
    print_header("Testing Core Imports")
    
    try:
        from app import app
        print("✅ Flask app imported")
        
        from models import db, Stock
        print("✅ Database models imported")
        
        from analyzer import StockAnalyzer
        print("✅ Stock analyzer imported")
        
        from data_fetcher import DataFetcher
        print("✅ Data fetcher imported")
        
        from scheduler import StockUpdateScheduler
        print("✅ Scheduler imported")
        
        print("\n✅ All core modules OK")
        return True
        
    except Exception as e:
        print(f"❌ Import error: {str(e)}")
        return False

def run_quick_test():
    """Rulează un test rapid al funcționalității"""
    print_header("Running Quick Functionality Test")
    
    try:
        from app import app
        from data_fetcher import DataFetcher
        from analyzer import StockAnalyzer
        from models import Stock, db
        
        # Test data fetcher
        fetcher = DataFetcher()
        print("✅ Data fetcher initialized")
        
        # Test getting stock list
        stocks = fetcher.get_stock_list()
        print(f"✅ Stock list loaded: {len(stocks)} stocks configured")
        
        # Test fetching data for one stock
        if stocks:
            symbol, name, sector = stocks[0]
            print(f"✅ Testing with {symbol}...")
            
            data = fetcher.fetch_all_data(symbol, name)
            print(f"✅ Data fetched for {symbol}")
            
            # Test creating stock object
            with app.app_context():
                stock = Stock(
                    symbol=symbol,
                    company_name=name,
                    sector=sector
                )
                
                # Update with fetched data
                for key, value in data.items():
                    if hasattr(stock, key):
                        setattr(stock, key, value)
                
                # Test analyzer
                stock = StockAnalyzer.analyze_stock(stock)
                print(f"✅ Stock analyzed: Score={stock.total_score:.2f}")
        
        print("\n✅ Functionality test passed")
        return True
        
    except Exception as e:
        print(f"❌ Functionality test failed: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main test runner"""
    print("\n" + "🧪 STOCK MARKET ANALYZER - SETUP TEST".center(60))
    
    tests = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("File Structure", check_file_structure),
        ("Core Imports", test_imports),
        ("Database", test_database),
        ("Functionality", run_quick_test)
    ]
    
    results = []
    
    for name, test_func in tests:
        try:
            result = test_func()
            results.append((name, result))
        except Exception as e:
            print(f"\n❌ Test '{name}' crashed: {str(e)}")
            results.append((name, False))
    
    # Summary
    print_header("TEST SUMMARY")
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {name}")
    
    print(f"\nResults: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED! 🎉")
        print("\nYou can now run the application:")
        print("  python app.py")
        print("\nOr use the start script:")
        print("  ./start.sh")
        return 0
    else:
        print("\n⚠️  SOME TESTS FAILED")
        print("\nPlease fix the issues above before running the application.")
        print("Check INSTALL.md for detailed setup instructions.")
        return 1

if __name__ == '__main__':
    sys.exit(main())
