"""
Data Fetcher - Obține date financiare de pe API-uri
Pentru demo, folosește date simulate dacă API keys nu sunt disponibile
"""
import os
import random
import requests
from datetime import datetime, timedelta
from textblob import TextBlob

class DataFetcher:
    """Fetcher pentru date financiare și sentiment"""
    
    # Lista de acțiuni populare pentru demo
    DEMO_STOCKS = [
        ('AAPL', 'Apple Inc.', 'Technology'),
        ('MSFT', 'Microsoft Corporation', 'Technology'),
        ('GOOGL', 'Alphabet Inc.', 'Technology'),
        ('AMZN', 'Amazon.com Inc.', 'Consumer Cyclical'),
        ('NVDA', 'NVIDIA Corporation', 'Technology'),
        ('TSLA', 'Tesla Inc.', 'Automotive'),
        ('META', 'Meta Platforms Inc.', 'Technology'),
        ('JPM', 'JPMorgan Chase & Co.', 'Financial'),
        ('V', 'Visa Inc.', 'Financial'),
        ('WMT', 'Walmart Inc.', 'Consumer Defensive'),
        ('DIS', 'Walt Disney Company', 'Entertainment'),
        ('NFLX', 'Netflix Inc.', 'Entertainment'),
        ('PYPL', 'PayPal Holdings Inc.', 'Financial'),
        ('INTC', 'Intel Corporation', 'Technology'),
        ('AMD', 'Advanced Micro Devices', 'Technology'),
        ('BA', 'Boeing Company', 'Aerospace'),
        ('NKE', 'Nike Inc.', 'Consumer Cyclical'),
        ('MCD', 'McDonald\'s Corporation', 'Consumer Cyclical'),
        ('KO', 'Coca-Cola Company', 'Consumer Defensive'),
        ('PEP', 'PepsiCo Inc.', 'Consumer Defensive'),
    ]
    
    def __init__(self):
        self.alpha_vantage_key = os.getenv('ALPHA_VANTAGE_API_KEY')
        self.news_api_key = os.getenv('NEWS_API_KEY')
        self.use_demo_data = not (self.alpha_vantage_key and self.news_api_key)
        
        if self.use_demo_data:
            print("⚠️  API keys not found - using simulated data for demo")
    
    def get_stock_list(self):
        """Returnează lista de acțiuni de urmărit"""
        return self.DEMO_STOCKS
    
    def fetch_price_data(self, symbol):
        """Obține date despre preț"""
        if self.use_demo_data:
            return self._generate_demo_price_data(symbol)
        
        try:
            # API real Alpha Vantage
            url = f'https://www.alphavantage.co/query'
            params = {
                'function': 'GLOBAL_QUOTE',
                'symbol': symbol,
                'apikey': self.alpha_vantage_key
            }
            response = requests.get(url, params=params, timeout=10)
            data = response.json()
            
            if 'Global Quote' in data:
                quote = data['Global Quote']
                return {
                    'current_price': float(quote.get('05. price', 0)),
                    'previous_close': float(quote.get('08. previous close', 0)),
                    'volume': int(quote.get('06. volume', 0)),
                }
        except Exception as e:
            print(f"Error fetching price for {symbol}: {e}")
            return self._generate_demo_price_data(symbol)
    
    def fetch_technical_indicators(self, symbol):
        """Obține indicatori tehnici"""
        if self.use_demo_data:
            return self._generate_demo_technical_data(symbol)
        
        # În producție, ar folosi API-uri reale
        return self._generate_demo_technical_data(symbol)
    
    def fetch_fundamental_data(self, symbol):
        """Obține date fundamentale"""
        if self.use_demo_data:
            return self._generate_demo_fundamental_data(symbol)
        
        # În producție, ar folosi API-uri reale
        return self._generate_demo_fundamental_data(symbol)
    
    def fetch_sentiment_data(self, symbol, company_name):
        """Obține date de sentiment din news și social media"""
        if self.use_demo_data:
            return self._generate_demo_sentiment_data(symbol)
        
        try:
            # News API real
            sentiment_data = {
                'news_sentiment': 0,
                'social_sentiment': 0,
                'market_correlation': 0
            }
            
            # Fetch news articles
            url = 'https://newsapi.org/v2/everything'
            params = {
                'q': company_name,
                'apiKey': self.news_api_key,
                'language': 'en',
                'sortBy': 'publishedAt',
                'pageSize': 20
            }
            
            response = requests.get(url, params=params, timeout=10)
            news_data = response.json()
            
            if news_data.get('status') == 'ok' and news_data.get('articles'):
                sentiments = []
                for article in news_data['articles'][:10]:
                    text = f"{article.get('title', '')} {article.get('description', '')}"
                    blob = TextBlob(text)
                    sentiments.append(blob.sentiment.polarity)
                
                sentiment_data['news_sentiment'] = sum(sentiments) / len(sentiments) if sentiments else 0
            
            # Simulează social sentiment și market correlation
            sentiment_data['social_sentiment'] = random.uniform(-0.5, 0.8)
            sentiment_data['market_correlation'] = random.uniform(-0.3, 0.9)
            
            return sentiment_data
            
        except Exception as e:
            print(f"Error fetching sentiment for {symbol}: {e}")
            return self._generate_demo_sentiment_data(symbol)
    
    def _generate_demo_price_data(self, symbol):
        """Generează date simulate de preț"""
        # Base price varies by symbol
        base_prices = {
            'AAPL': 175, 'MSFT': 410, 'GOOGL': 140, 'AMZN': 175,
            'NVDA': 880, 'TSLA': 175, 'META': 485, 'JPM': 195,
            'V': 270, 'WMT': 165, 'DIS': 112, 'NFLX': 610,
            'PYPL': 62, 'INTC': 43, 'AMD': 185, 'BA': 210,
            'NKE': 105, 'MCD': 295, 'KO': 61, 'PEP': 170
        }
        
        base_price = base_prices.get(symbol, 100)
        current_price = base_price * random.uniform(0.95, 1.05)
        previous_close = current_price * random.uniform(0.97, 1.03)
        
        return {
            'current_price': round(current_price, 2),
            'previous_close': round(previous_close, 2),
            'volume': random.randint(10000000, 100000000),
        }
    
    def _generate_demo_technical_data(self, symbol):
        """Generează indicatori tehnici simulați"""
        return {
            'rsi': round(random.uniform(25, 75), 2),
            'macd': round(random.uniform(-2, 2), 4),
            'macd_signal': round(random.uniform(-2, 2), 4),
            'sma_50': round(random.uniform(90, 110), 2),
            'sma_200': round(random.uniform(85, 115), 2),
            'avg_volume': random.randint(20000000, 80000000),
        }
    
    def _generate_demo_fundamental_data(self, symbol):
        """Generează date fundamentale simulate"""
        return {
            'pe_ratio': round(random.uniform(10, 45), 2),
            'eps': round(random.uniform(2, 15), 2),
            'eps_growth': round(random.uniform(-10, 25), 2),
            'revenue_growth': round(random.uniform(-5, 20), 2),
            'debt_to_equity': round(random.uniform(0.2, 2.5), 2),
            'market_cap': random.randint(50000000000, 3000000000000),
        }
    
    def _generate_demo_sentiment_data(self, symbol):
        """Generează date de sentiment simulate"""
        # Creează pattern-uri realiste de sentiment
        sentiment_bias = random.choice([-0.3, 0, 0.3, 0.5])  # Unele acțiuni mai bullish
        
        return {
            'news_sentiment': round(random.uniform(-0.5, 0.8) + sentiment_bias, 3),
            'social_sentiment': round(random.uniform(-0.4, 0.9) + sentiment_bias, 3),
            'market_correlation': round(random.uniform(-0.2, 0.9), 3),
        }
    
    def fetch_all_data(self, symbol, company_name):
        """Obține toate datele pentru o acțiune"""
        print(f"Fetching data for {symbol}...")
        
        price_data = self.fetch_price_data(symbol)
        technical_data = self.fetch_technical_indicators(symbol)
        fundamental_data = self.fetch_fundamental_data(symbol)
        sentiment_data = self.fetch_sentiment_data(symbol, company_name)
        
        return {
            **price_data,
            **technical_data,
            **fundamental_data,
            **sentiment_data
        }
