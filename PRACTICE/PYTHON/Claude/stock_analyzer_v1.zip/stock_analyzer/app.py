"""
Stock Market Analyzer - Flask Application
"""
from flask import Flask, render_template, jsonify, request
from datetime import datetime, timedelta
import os
import time

from models import db, Stock, UpdateLog, StockHistory
from analyzer import StockAnalyzer
from data_fetcher import DataFetcher

# Initialize Flask app
app = Flask(__name__)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.urandom(24)

# Initialize database
db.init_app(app)

# Initialize data fetcher
data_fetcher = DataFetcher()


@app.route('/')
def index():
    """Dashboard principal"""
    return render_template('index.html')


@app.route('/stock/<symbol>')
def stock_detail(symbol):
    """Pagină detalii pentru o acțiune"""
    return render_template('stock_detail.html', symbol=symbol)


@app.route('/settings')
def settings():
    """Pagină setări"""
    return render_template('settings.html')


# ==================== API ENDPOINTS ====================

@app.route('/api/stocks')
def get_stocks():
    """Returnează toate acțiunile cu scoring"""
    # Parametri de filtrare și sortare
    sentiment_filter = request.args.get('sentiment')
    min_score = request.args.get('min_score', type=float)
    max_score = request.args.get('max_score', type=float)
    sector = request.args.get('sector')
    sort_by = request.args.get('sort_by', 'total_score')
    order = request.args.get('order', 'desc')
    
    # Query de bază
    query = Stock.query
    
    # Aplicare filtre
    if sentiment_filter:
        query = query.filter(Stock.sentiment_class == sentiment_filter)
    
    if min_score is not None:
        query = query.filter(Stock.total_score >= min_score)
    
    if max_score is not None:
        query = query.filter(Stock.total_score <= max_score)
    
    if sector:
        query = query.filter(Stock.sector == sector)
    
    # Sortare
    if hasattr(Stock, sort_by):
        sort_column = getattr(Stock, sort_by)
        if order == 'desc':
            query = query.order_by(sort_column.desc())
        else:
            query = query.order_by(sort_column.asc())
    
    stocks = query.all()
    
    # Get last update info
    last_log = UpdateLog.query.order_by(UpdateLog.created_at.desc()).first()
    last_update = last_log.created_at.isoformat() if last_log else None
    
    return jsonify({
        'stocks': [stock.to_dict() for stock in stocks],
        'total_count': len(stocks),
        'last_update': last_update,
        'filters_applied': {
            'sentiment': sentiment_filter,
            'min_score': min_score,
            'max_score': max_score,
            'sector': sector,
            'sort_by': sort_by,
            'order': order
        }
    })


@app.route('/api/stock/<symbol>')
def get_stock(symbol):
    """Detalii complete pentru o acțiune"""
    stock = Stock.query.filter_by(symbol=symbol.upper()).first()
    
    if not stock:
        return jsonify({'error': 'Stock not found'}), 404
    
    # Get historical data for charts (last 30 days)
    history = StockHistory.query.filter_by(stock_id=stock.id)\
        .filter(StockHistory.recorded_at >= datetime.utcnow() - timedelta(days=30))\
        .order_by(StockHistory.recorded_at.asc())\
        .all()
    
    return jsonify({
        'stock': stock.to_dict(),
        'history': [{
            'date': h.recorded_at.isoformat(),
            'price': h.price,
            'score': h.total_score,
            'volume': h.volume
        } for h in history]
    })


@app.route('/api/sectors')
def get_sectors():
    """Returnează toate sectoarele disponibile"""
    sectors = db.session.query(Stock.sector).distinct().all()
    return jsonify({
        'sectors': [s[0] for s in sectors if s[0]]
    })


@app.route('/api/update', methods=['POST'])
def trigger_update():
    """Trigger manual pentru update-ul datelor"""
    start_time = datetime.utcnow()
    update_type = request.json.get('update_type', 'manual') if request.json else 'manual'
    
    try:
        print(f"\n{'='*60}")
        print(f"🔄 Starting {update_type} update at {start_time}")
        print(f"{'='*60}\n")
        
        # Get stock list
        stock_list = data_fetcher.get_stock_list()
        updated_count = 0
        
        for symbol, company_name, sector in stock_list:
            try:
                # Fetch all data
                data = data_fetcher.fetch_all_data(symbol, company_name)
                
                # Get or create stock
                stock = Stock.query.filter_by(symbol=symbol).first()
                if not stock:
                    stock = Stock(
                        symbol=symbol,
                        company_name=company_name,
                        sector=sector
                    )
                    db.session.add(stock)
                
                # Update stock data
                for key, value in data.items():
                    if hasattr(stock, key):
                        setattr(stock, key, value)
                
                # Analyze and calculate scores
                stock = StockAnalyzer.analyze_stock(stock)
                
                # Save to history
                StockAnalyzer.save_history(stock)
                
                db.session.commit()
                updated_count += 1
                
                print(f"✓ Updated {symbol}: Score={stock.total_score:.2f}, "
                      f"Price=${stock.current_price:.2f}, "
                      f"Target=${stock.target_price:.2f}")
                
            except Exception as e:
                print(f"✗ Error updating {symbol}: {str(e)}")
                db.session.rollback()
                continue
        
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        # Log update
        log = UpdateLog(
            update_type=update_type,
            start_time=start_time,
            end_time=end_time,
            stocks_updated=updated_count,
            status='success' if updated_count > 0 else 'failed'
        )
        db.session.add(log)
        db.session.commit()
        
        print(f"\n{'='*60}")
        print(f"✅ Update completed!")
        print(f"📊 Updated: {updated_count}/{len(stock_list)} stocks")
        print(f"⏱️  Duration: {duration:.2f} seconds")
        print(f"{'='*60}\n")
        
        return jsonify({
            'status': 'success',
            'updated_stocks': updated_count,
            'total_stocks': len(stock_list),
            'duration': duration,
            'update_type': update_type
        })
        
    except Exception as e:
        end_time = datetime.utcnow()
        duration = (end_time - start_time).total_seconds()
        
        # Log failed update
        log = UpdateLog(
            update_type=update_type,
            start_time=start_time,
            end_time=end_time,
            stocks_updated=0,
            status='failed',
            error_message=str(e)
        )
        db.session.add(log)
        db.session.commit()
        
        print(f"\n❌ Update failed: {str(e)}\n")
        
        return jsonify({
            'status': 'error',
            'message': str(e),
            'duration': duration
        }), 500


@app.route('/api/stats')
def get_stats():
    """Statistici generale"""
    total_stocks = Stock.query.count()
    bullish = Stock.query.filter(Stock.total_score >= 60).count()
    bearish = Stock.query.filter(Stock.total_score < 40).count()
    
    avg_score = db.session.query(db.func.avg(Stock.total_score)).scalar() or 0
    
    # Top performers
    top_stocks = Stock.query.order_by(Stock.total_score.desc()).limit(5).all()
    
    # Recent updates
    recent_logs = UpdateLog.query.order_by(UpdateLog.created_at.desc()).limit(10).all()
    
    return jsonify({
        'total_stocks': total_stocks,
        'bullish_count': bullish,
        'bearish_count': bearish,
        'neutral_count': total_stocks - bullish - bearish,
        'average_score': round(avg_score, 2),
        'top_performers': [stock.to_dict() for stock in top_stocks],
        'recent_updates': [{
            'type': log.update_type,
            'time': log.created_at.isoformat(),
            'stocks_updated': log.stocks_updated,
            'status': log.status
        } for log in recent_logs]
    })


@app.route('/api/history/<symbol>')
def get_history(symbol):
    """Istoric pentru o acțiune (pentru grafice)"""
    days = request.args.get('days', 30, type=int)
    
    stock = Stock.query.filter_by(symbol=symbol.upper()).first()
    if not stock:
        return jsonify({'error': 'Stock not found'}), 404
    
    cutoff_date = datetime.utcnow() - timedelta(days=days)
    history = StockHistory.query.filter_by(stock_id=stock.id)\
        .filter(StockHistory.recorded_at >= cutoff_date)\
        .order_by(StockHistory.recorded_at.asc())\
        .all()
    
    return jsonify({
        'symbol': symbol,
        'history': [{
            'date': h.recorded_at.isoformat(),
            'price': h.price,
            'score': h.total_score,
            'volume': h.volume
        } for h in history]
    })


def init_database():
    """Initialize database și populează cu date inițiale"""
    with app.app_context():
        # Create tables
        db.create_all()
        
        # Check if we need to populate
        if Stock.query.count() == 0:
            print("📊 Database is empty, running initial data fetch...")
            
            # Trigger initial update
            with app.test_client() as client:
                client.post('/api/update', json={'update_type': 'initial'})
            
            print("✅ Initial data loaded successfully!")
        else:
            print(f"✅ Database already contains {Stock.query.count()} stocks")


if __name__ == '__main__':
    # Initialize database on startup
    init_database()
    
    # Run Flask app
    print("\n" + "="*60)
    print("🚀 Starting Stock Market Analyzer")
    print("="*60)
    print(f"📍 Server: http://localhost:5000")
    print(f"📊 Dashboard: http://localhost:5000")
    print(f"⚙️  Settings: http://localhost:5000/settings")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
