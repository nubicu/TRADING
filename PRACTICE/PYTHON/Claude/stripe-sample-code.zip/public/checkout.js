// This is your test publishable API key.
const stripe = Stripe("pk_test_51T6sw0KetllVyOWZBU9vwhrqslYFi7cArcALUu689zCDJgA9OpbErzzW7U1UcAAMGxSgTcnX9GNEP4KflbCY1jLP003iasFQ0e");

initialize();

// Create a Checkout Session
async function initialize() {
  const fetchClientSecret = async () => {
    const response = await fetch("/create-checkout-session", {
      method: "POST",
    });
    const { clientSecret } = await response.json();
    return clientSecret;
  };

  const checkout = await stripe.initEmbeddedCheckout({
    fetchClientSecret,
  });

  // Mount Checkout
  checkout.mount('#checkout');
}